import { pgTable, text, serial, timestamp, boolean, integer, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const suppliersTable = pgTable("suppliers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  country: text("country").notNull().default("China"),
  logoUrl: text("logo_url"),
  description: text("description"),
  website: text("website"),
  email: text("email"),
  isActive: boolean("is_active").notNull().default(true),
  categories: text("categories").array().notNull().default([]),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const supplierProductsTable = pgTable("supplier_products", {
  id: serial("id").primaryKey(),
  supplierId: integer("supplier_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  price: real("price").notNull().default(0),
  imageUrl: text("image_url"),
  category: text("category"),
  moq: integer("moq").notNull().default(1),
  shippingDays: integer("shipping_days").notNull().default(14),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertSupplierSchema = createInsertSchema(suppliersTable).omit({ id: true, createdAt: true });
export type InsertSupplier = z.infer<typeof insertSupplierSchema>;
export type Supplier = typeof suppliersTable.$inferSelect;
export type SupplierProduct = typeof supplierProductsTable.$inferSelect;
