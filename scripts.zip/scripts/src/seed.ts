import { db } from "@workspace/db";
import { plansTable, suppliersTable, supplierProductsTable, usersTable, subscriptionsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import bcrypt from "bcrypt";

async function seed() {
  console.log("Seeding database...");

  const existingPlans = await db.select().from(plansTable);
  if (existingPlans.length === 0) {
    await db.insert(plansTable).values([
      {
        name: "Free",
        price: 0,
        interval: "month",
        maxStores: 1,
        maxProducts: 1,
        features: ["1 store", "1 product", "Basic analytics", "Community support"],
        isPopular: false,
      },
      {
        name: "Monthly",
        price: 21,
        interval: "month",
        maxStores: 5,
        maxProducts: 500,
        features: ["5 stores", "500 products/store", "AI store builder", "AI product generator", "Email support", "Advanced analytics"],
        isPopular: false,
      },
      {
        name: "Annual",
        price: 199,
        interval: "year",
        maxStores: 17,
        maxProducts: 1000,
        features: ["17 stores", "1000 products/store", "AI store builder", "AI product generator", "Priority support", "Advanced analytics", "Custom domain"],
        isPopular: true,
      },
      {
        name: "Premium Monthly",
        price: 25,
        interval: "month",
        maxStores: 20,
        maxProducts: 5000,
        features: ["20 stores", "Unlimited products", "AI store builder", "AI product generator", "Dedicated support", "White-label", "API access"],
        isPopular: false,
      },
      {
        name: "Premium Annual",
        price: 249,
        interval: "year",
        maxStores: 99,
        maxProducts: null,
        features: ["Unlimited stores", "Unlimited products", "AI store builder", "AI product generator", "Dedicated manager", "White-label", "API access", "Custom integrations"],
        isPopular: false,
      },
    ]);
    console.log("Plans seeded.");
  }

  const existingSuppliers = await db.select().from(suppliersTable);
  if (existingSuppliers.length === 0) {
    const supplierRows = await db.insert(suppliersTable).values([
      {
        name: "CJ Dropshipping",
        country: "China",
        description: "One of the world's largest dropshipping suppliers with 400,000+ products, fast shipping, and global warehouses.",
        website: "https://cjdropshipping.com",
        email: "support@cjdropshipping.com",
        isActive: true,
        categories: ["Electronics", "Fashion", "Home", "Beauty", "Sports", "Toys"],
      },
      {
        name: "AliExpress Wholesale",
        country: "China",
        description: "Massive marketplace with millions of products, competitive pricing, and worldwide shipping from verified suppliers.",
        website: "https://aliexpress.com",
        email: "wholesale@aliexpress.com",
        isActive: true,
        categories: ["Electronics", "Clothing", "Jewelry", "Home", "Garden", "Automotive"],
      },
      {
        name: "Spocket",
        country: "USA",
        description: "Premium US/EU-based supplier network with fast shipping (2-5 days) and high-quality branded products.",
        website: "https://spocket.co",
        email: "support@spocket.co",
        isActive: true,
        categories: ["Fashion", "Home", "Beauty", "Pet", "Accessories"],
      },
      {
        name: "SaleHoo",
        country: "New Zealand",
        description: "Verified supplier directory with 8,000+ pre-screened wholesale and dropshipping suppliers.",
        website: "https://salehoo.com",
        email: "support@salehoo.com",
        isActive: true,
        categories: ["Electronics", "Fashion", "Health", "Home", "Sports"],
      },
      {
        name: "Printful",
        country: "USA",
        description: "Print-on-demand and dropshipping for custom merchandise — apparel, accessories, home decor.",
        website: "https://printful.com",
        email: "support@printful.com",
        isActive: true,
        categories: ["Apparel", "Accessories", "Home Decor", "Stationery"],
      },
    ]).returning();

    const supplierMap = new Map(supplierRows.map(s => [s.name, s.id]));

    await db.insert(supplierProductsTable).values([
      { supplierId: supplierMap.get("CJ Dropshipping")!, name: "Wireless Earbuds Pro X", description: "Bluetooth 5.3, 40h battery, ANC, IPX5 waterproof", price: 12.99, category: "Electronics", moq: 1, shippingDays: 10 },
      { supplierId: supplierMap.get("CJ Dropshipping")!, name: "LED Strip Light 10m RGB", description: "App-controlled, music sync, 16 million colors", price: 8.50, category: "Home", moq: 2, shippingDays: 12 },
      { supplierId: supplierMap.get("CJ Dropshipping")!, name: "Portable Neck Fan", description: "360° cooling, 3 speeds, USB-C, 8h battery", price: 9.99, category: "Electronics", moq: 1, shippingDays: 9 },
      { supplierId: supplierMap.get("AliExpress Wholesale")!, name: "Stainless Steel Tumbler 40oz", description: "Double-wall insulated, keeps hot/cold 24h, leak-proof", price: 6.20, category: "Home", moq: 5, shippingDays: 14 },
      { supplierId: supplierMap.get("AliExpress Wholesale")!, name: "Magnetic Phone Wallet", description: "MagSafe compatible, RFID-blocking, holds 3 cards", price: 3.80, category: "Accessories", moq: 10, shippingDays: 16 },
      { supplierId: supplierMap.get("Spocket")!, name: "Natural Silk Pillowcase", description: "100% mulberry silk, 22 momme, anti-aging, queen size", price: 18.00, category: "Home", moq: 1, shippingDays: 4 },
      { supplierId: supplierMap.get("Spocket")!, name: "Bamboo Skincare Set", description: "Vitamin C serum + moisturizer + face wash, vegan formula", price: 22.00, category: "Beauty", moq: 1, shippingDays: 3 },
      { supplierId: supplierMap.get("Printful")!, name: "Custom Print Hoodie", description: "Unisex, 80% cotton, full-color DTG print, S-3XL", price: 28.00, category: "Apparel", moq: 1, shippingDays: 5 },
    ]);

    console.log("Suppliers and products seeded.");
  }

  const existingAdmin = await db.select().from(usersTable).where(eq(usersTable.email, "admin@mehna.com"));
  if (existingAdmin.length === 0) {
    const passwordHash = await bcrypt.hash("admin123", 10);
    const [admin] = await db.insert(usersTable).values({
      email: "admin@mehna.com",
      passwordHash,
      name: "Mehna Admin",
      role: "admin",
    }).returning();

    const [freePlan] = await db.select().from(plansTable).where(eq(plansTable.name, "Free"));
    await db.insert(subscriptionsTable).values({ userId: admin.id, planId: freePlan.id, status: "free" });
    console.log("Admin user seeded. Email: admin@mehna.com, Password: admin123");
  }

  console.log("Seeding complete!");
  process.exit(0);
}

seed().catch(err => {
  console.error("Seed error:", err);
  process.exit(1);
});
