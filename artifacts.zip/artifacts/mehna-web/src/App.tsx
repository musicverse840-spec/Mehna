import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/hooks/use-auth";
import { AppLayout } from "@/components/layout/app-layout";

import Landing from "@/pages/landing";
import Login from "@/pages/login";
import Register from "@/pages/register";
import Dashboard from "@/pages/dashboard";
import Chat from "@/pages/chat";
import Pricing from "@/pages/pricing";
import Settings from "@/pages/settings";
import Suppliers from "@/pages/suppliers";
import Admin from "@/pages/admin";

import NewStore from "@/pages/stores/new";
import StoreDetail from "@/pages/stores/detail";
import StoreProducts from "@/pages/stores/products";
import NewProduct from "@/pages/stores/new-product";
import StoreOrders from "@/pages/stores/orders";
import OrderDetail from "@/pages/stores/order-detail";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      staleTime: 30_000,
    },
  },
});

function ProtectedRoute({ component: Component, ...rest }: { component: React.ComponentType<Record<string, string>> }) {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black">
        <div className="w-8 h-8 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) {
    window.location.href = `${import.meta.env.BASE_URL}login`.replace("//", "/");
    return null;
  }

  return (
    <AppLayout>
      <Component {...(rest as Record<string, string>)} />
    </AppLayout>
  );
}

function AdminRoute({ component: Component }: { component: React.ComponentType<Record<string, string>> }) {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black">
        <div className="w-8 h-8 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (!user || user.role !== "admin") {
    window.location.href = `${import.meta.env.BASE_URL}dashboard`.replace("//", "/");
    return null;
  }

  return (
    <AppLayout>
      <Component />
    </AppLayout>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Landing} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />

      <Route path="/dashboard">
        {() => <ProtectedRoute component={Dashboard} />}
      </Route>
      <Route path="/chat">
        {() => <ProtectedRoute component={Chat} />}
      </Route>
      <Route path="/pricing">
        {() => <ProtectedRoute component={Pricing} />}
      </Route>
      <Route path="/settings">
        {() => <ProtectedRoute component={Settings} />}
      </Route>
      <Route path="/suppliers">
        {() => <ProtectedRoute component={Suppliers} />}
      </Route>

      <Route path="/stores/new">
        {() => <ProtectedRoute component={NewStore} />}
      </Route>
      <Route path="/stores/:storeId">
        {(params) => <ProtectedRoute component={StoreDetail} {...params} />}
      </Route>
      <Route path="/stores/:storeId/products/new">
        {(params) => <ProtectedRoute component={NewProduct} {...params} />}
      </Route>
      <Route path="/stores/:storeId/products">
        {(params) => <ProtectedRoute component={StoreProducts} {...params} />}
      </Route>
      <Route path="/stores/:storeId/orders/:orderId">
        {(params) => <ProtectedRoute component={OrderDetail} {...params} />}
      </Route>
      <Route path="/stores/:storeId/orders">
        {(params) => <ProtectedRoute component={StoreOrders} {...params} />}
      </Route>

      <Route path="/admin">
        {() => <AdminRoute component={Admin} />}
      </Route>

      <Route>
        <div className="min-h-screen flex items-center justify-center bg-black">
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-2">404</h1>
            <p className="text-muted-foreground">Page not found.</p>
          </div>
        </div>
      </Route>
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <AuthProvider>
            <Router />
          </AuthProvider>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
