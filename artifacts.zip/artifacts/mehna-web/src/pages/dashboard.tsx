import { useListStores } from "@workspace/api-client-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Store, ArrowRight } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function Dashboard() {
  const { data: stores, isLoading } = useListStores();

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground mt-1">Manage your empire.</p>
        </div>
        <Link href="/stores/new">
          <Button className="bg-primary text-black hover:bg-primary/90 font-semibold shadow-sm">
            <Plus className="w-4 h-4 mr-2" />
            Create Store
          </Button>
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {isLoading ? (
          Array.from({ length: 3 }).map((_, i) => (
            <Card key={i} className="bg-card">
              <CardHeader className="pb-2">
                <Skeleton className="h-6 w-24 mb-2" />
                <Skeleton className="h-4 w-40" />
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-end mt-4">
                  <Skeleton className="h-8 w-16" />
                  <Skeleton className="h-8 w-24" />
                </div>
              </CardContent>
            </Card>
          ))
        ) : stores?.length === 0 ? (
          <div className="col-span-full flex flex-col items-center justify-center p-12 bg-card rounded-lg border border-dashed text-center">
            <div className="w-16 h-16 bg-primary/20 text-primary rounded-full flex items-center justify-center mb-4">
              <Store className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-semibold mb-2">No stores yet</h3>
            <p className="text-muted-foreground mb-6 max-w-md">
              Launch your first AI-powered store in seconds. Just describe what you want to sell.
            </p>
            <Link href="/stores/new">
              <Button className="bg-primary text-black hover:bg-primary/90">
                Generate Store
              </Button>
            </Link>
          </div>
        ) : (
          stores?.map((store) => (
            <Card key={store.id} className="bg-card hover:border-primary/50 transition-colors group">
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <div className="w-10 h-10 rounded bg-primary/10 text-primary flex items-center justify-center font-bold mb-2">
                    {store.logoUrl ? <img src={store.logoUrl} alt={store.name} className="w-full h-full object-cover rounded" /> : store.name.charAt(0)}
                  </div>
                  <span className="text-xs px-2 py-1 bg-zinc-800 rounded-full text-zinc-300 font-medium">
                    {store.status}
                  </span>
                </div>
                <CardTitle className="text-lg">{store.name}</CardTitle>
                <p className="text-sm text-muted-foreground line-clamp-1">{store.description || "No description"}</p>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center mt-4">
                  <div className="text-sm text-muted-foreground">
                    <span className="font-medium text-foreground">0</span> orders
                  </div>
                  <Link href={`/stores/${store.id}`}>
                    <Button variant="ghost" size="sm" className="group-hover:text-primary transition-colors">
                      Manage
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
