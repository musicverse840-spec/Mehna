import { useState } from "react";
import { useListSuppliers, getListSuppliersQueryKey, useListSupplierProducts, getListSupplierProductsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Search, Globe, Package, ChevronRight, ChevronDown } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";

export default function Suppliers() {
  const [search, setSearch] = useState("");
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const qc = useQueryClient();

  const { data: suppliers, isLoading } = useListSuppliers({ search: search || undefined }, {
    query: { queryKey: getListSuppliersQueryKey({ search: search || undefined }) },
  });

  const { data: supplierProducts, isLoading: productsLoading } = useListSupplierProducts(
    expandedId ?? 0,
    { query: { enabled: !!expandedId, queryKey: getListSupplierProductsQueryKey(expandedId ?? 0) } }
  );

  const toggleExpanded = (id: number) => {
    setExpandedId(prev => prev === id ? null : id);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Suppliers</h1>
        <p className="text-muted-foreground mt-1">Browse verified dropshipping suppliers and their catalogs.</p>
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search suppliers..."
          className="pl-9 bg-black/50 border-white/10"
        />
      </div>

      {isLoading ? (
        <div className="space-y-4">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-32 w-full" />)}
        </div>
      ) : (
        <div className="space-y-4">
          {suppliers?.map(supplier => (
            <Card key={supplier.id} className="bg-card overflow-hidden">
              <div
                className="flex items-center justify-between p-5 cursor-pointer hover:bg-white/2 transition-colors"
                onClick={() => toggleExpanded(supplier.id)}
              >
                <div className="flex items-center gap-4">
                  {supplier.logoUrl ? (
                    <img src={supplier.logoUrl} alt={supplier.name} className="w-12 h-12 rounded object-cover" />
                  ) : (
                    <div className="w-12 h-12 rounded bg-primary/10 text-primary flex items-center justify-center font-bold text-lg">
                      {supplier.name.charAt(0)}
                    </div>
                  )}
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold">{supplier.name}</h3>
                      <span className="text-xs px-2 py-0.5 bg-white/5 rounded-full text-muted-foreground">{supplier.country}</span>
                    </div>
                    <p className="text-sm text-muted-foreground mt-0.5 line-clamp-1">{supplier.description}</p>
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      {supplier.categories?.map(cat => (
                        <span key={cat} className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full">{cat}</span>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  {supplier.website && (
                    <a href={supplier.website} target="_blank" rel="noopener noreferrer" onClick={e => e.stopPropagation()}
                      className="text-muted-foreground hover:text-primary transition-colors">
                      <Globe className="w-4 h-4" />
                    </a>
                  )}
                  {expandedId === supplier.id ? <ChevronDown className="w-5 h-5 text-muted-foreground" /> : <ChevronRight className="w-5 h-5 text-muted-foreground" />}
                </div>
              </div>

              {expandedId === supplier.id && (
                <div className="border-t border-white/5 p-5">
                  <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
                    <Package className="w-4 h-4" /> Sample Products
                  </h4>
                  {productsLoading ? (
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-24" />)}
                    </div>
                  ) : supplierProducts?.length === 0 ? (
                    <p className="text-sm text-muted-foreground">No products listed.</p>
                  ) : (
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      {supplierProducts?.map(prod => (
                        <div key={prod.id} className="bg-black/30 rounded-lg p-3 border border-white/5">
                          {prod.imageUrl && <img src={prod.imageUrl} alt={prod.name} className="w-full h-24 object-cover rounded mb-2" />}
                          <p className="text-sm font-medium line-clamp-2">{prod.name}</p>
                          <p className="text-primary font-bold text-sm mt-1">${prod.price}</p>
                          <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                            <span>MOQ: {prod.moq}</span>
                            <span>·</span>
                            <span>{prod.shippingDays}d ship</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
