import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function Landing() {
  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      <header className="px-6 py-4 flex items-center justify-between border-b border-white/10">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-primary rounded flex items-center justify-center font-bold text-black">M</div>
          <span className="text-xl font-bold tracking-tight">Mehna</span>
        </div>
        <nav className="hidden md:flex gap-6 items-center">
          <a href="#features" className="text-sm font-medium text-white/70 hover:text-white transition-colors">Features</a>
          <a href="#pricing" className="text-sm font-medium text-white/70 hover:text-white transition-colors">Pricing</a>
          <Link href="/login" className="text-sm font-medium text-white hover:text-primary transition-colors">Log in</Link>
          <Link href="/register" className="bg-primary text-black px-4 py-2 rounded-md text-sm font-bold hover:bg-primary/90 transition-colors">
            Get Started
          </Link>
        </nav>
      </header>

      <main className="flex-1 flex flex-col">
        <section className="flex-1 flex flex-col items-center justify-center text-center px-4 py-20 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/10 via-black to-black">
          <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight max-w-4xl mb-6">
            Build your dropshipping empire from a <span className="text-primary">single prompt.</span>
          </h1>
          <p className="text-lg md:text-xl text-white/70 max-w-2xl mb-10">
            Mehna is the AI-powered command center for ambitious store owners. Generate full stores, source products, and manage orders seamlessly.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Link href="/register" className="bg-primary text-black px-8 py-4 rounded-md text-lg font-bold hover:bg-primary/90 transition-colors flex items-center justify-center gap-2">
              Start Building Now
            </Link>
          </div>
        </section>
      </main>
    </div>
  );
}
