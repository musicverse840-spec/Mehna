import { useParams } from "wouter";
import { useGetOrder, getGetOrderQueryKey, useNotifySupplier } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { Bell, MapPin, Mail, User, Package, DollarSign } from "lucide-react";

export default function OrderDetail() {
  const params = useParams<{ storeId: string; orderId: string }>();
  const storeId = parseInt(params.storeId, 10);
  const orderId = parseInt(params.orderId, 10);
  const { toast } = useToast();
  const qc = useQueryClient();

  const { data: order, isLoading } = useGetOrder(storeId, orderId, {
    query: { enabled: !!storeId && !!orderId, queryKey: getGetOrderQueryKey(storeId, orderId) },
  });

  const notifySupplier = useNotifySupplier();

  const handleNotify = () => {
    notifySupplier.mutate({ storeId, orderId }, {
      onSuccess: (res) => {
        qc.invalidateQueries({ queryKey: getGetOrderQueryKey(storeId, orderId) });
        toast({ title: "Supplier notified!", description: res.message });
      },
      onError: () => toast({ title: "Notification failed", variant: "destructive" }),
    });
  };

  if (isLoading) return <div className="space-y-4">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-24 w-full" />)}</div>;
  if (!order) return <div className="text-muted-foreground">Order not found.</div>;

  const items = (order as typeof order & { items?: Array<{ productId: number; productName: string; quantity: number; price: number }> }).items ?? [];

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Order #{order.id}</h1>
          <p className="text-muted-foreground mt-1">Placed on {new Date(order.createdAt).toLocaleDateString()}</p>
        </div>
        <Button
          onClick={handleNotify}
          disabled={order.supplierNotified || notifySupplier.isPending}
          className={order.supplierNotified ? "bg-green-600 text-white" : "bg-primary text-black hover:bg-primary/90 font-semibold"}
        >
          <Bell className="w-4 h-4 mr-2" />
          {order.supplierNotified ? "Supplier Notified" : "Notify Supplier"}
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="bg-card">
          <CardHeader><CardTitle className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Customer</CardTitle></CardHeader>
          <CardContent className="space-y-2 pt-0">
            <div className="flex items-center gap-2 text-sm"><User className="w-4 h-4 text-muted-foreground" />{order.customerName}</div>
            <div className="flex items-center gap-2 text-sm"><Mail className="w-4 h-4 text-muted-foreground" />{order.customerEmail}</div>
            <div className="flex items-start gap-2 text-sm"><MapPin className="w-4 h-4 text-muted-foreground flex-shrink-0 mt-0.5" />{order.shippingAddress}</div>
          </CardContent>
        </Card>

        <Card className="bg-card">
          <CardHeader><CardTitle className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Financials</CardTitle></CardHeader>
          <CardContent className="space-y-3 pt-0">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Subtotal</span>
              <span>${order.total.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Platform Fee (5%)</span>
              <span className="text-yellow-500">-${order.platformFee.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm border-t border-white/10 pt-2 mt-2">
              <span className="font-semibold">Your Earnings</span>
              <span className="font-bold text-green-400">${order.ownerAmount.toFixed(2)}</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-card">
        <CardHeader><CardTitle className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Order Items</CardTitle></CardHeader>
        <CardContent className="pt-0">
          {items.length === 0 ? (
            <p className="text-muted-foreground text-sm">No items.</p>
          ) : (
            <div className="space-y-3">
              {items.map((item, i) => (
                <div key={i} className="flex items-center justify-between py-2 border-b border-white/5 last:border-0">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded bg-white/5 flex items-center justify-center">
                      <Package className="w-4 h-4 text-muted-foreground" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">{item.productName}</p>
                      <p className="text-xs text-muted-foreground">Qty: {item.quantity}</p>
                    </div>
                  </div>
                  <p className="font-semibold text-sm">${(item.price * item.quantity).toFixed(2)}</p>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
