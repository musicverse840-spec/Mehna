import { useState, useRef } from "react";
import { useParams, useLocation } from "wouter";
import { useCreateProduct } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Upload, ImageIcon, X } from "lucide-react";

export default function NewProduct() {
  const params = useParams<{ storeId: string }>();
  const storeId = parseInt(params.storeId, 10);
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);

  const createProduct = useCreateProduct();

  const isValid = name.trim() && description.trim() && price && imageFile;

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      toast({ title: "Invalid file", description: "Please select an image file.", variant: "destructive" });
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      toast({ title: "File too large", description: "Image must be under 5MB.", variant: "destructive" });
      return;
    }
    setImageFile(file);
    const reader = new FileReader();
    reader.onload = (ev) => setImagePreview(ev.target?.result as string);
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isValid) return;

    try {
      setUploading(true);
      let imageUrl: string | undefined;

      if (imageFile) {
        const formData = new FormData();
        formData.append("image", imageFile);
        const token = localStorage.getItem("token");
        const res = await fetch(`/api/stores/${storeId}/products/upload-image`, {
          method: "POST",
          headers: token ? { Authorization: `Bearer ${token}` } : {},
          body: formData,
        });
        if (!res.ok) throw new Error("Upload failed");
        const data = await res.json() as { url: string };
        imageUrl = data.url;
      }

      setUploading(false);

      createProduct.mutate({
        storeId,
        data: {
          name: name.trim(),
          description: description.trim(),
          price: parseFloat(price),
          imageUrl,
          inventory: 100,
        },
      }, {
        onSuccess: () => {
          toast({ title: "Product added!", description: "Your product is now live in your store." });
          setLocation(`/stores/${storeId}/products`);
        },
        onError: () => {
          setUploading(false);
          toast({ title: "Failed to add product", variant: "destructive" });
        },
      });
    } catch {
      setUploading(false);
      toast({ title: "Image upload failed", variant: "destructive" });
    }
  };

  const isPending = uploading || createProduct.isPending;

  return (
    <div className="max-w-xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Add Product</h1>
        <p className="text-muted-foreground mt-1">Fill in all fields to add a product to your store.</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="space-y-2">
          <Label>
            Product Name <span className="text-red-400">*</span>
          </Label>
          <Input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. Wireless Earbuds Pro"
            className="bg-black/50 border-white/10"
            required
          />
        </div>

        <div className="space-y-2">
          <Label>
            Description <span className="text-red-400">*</span>
          </Label>
          <Textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Describe your product — features, materials, benefits..."
            className="bg-black/50 border-white/10 resize-none"
            rows={4}
            required
          />
        </div>

        <div className="space-y-2">
          <Label>
            Product Image <span className="text-red-400">*</span>
          </Label>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleImageChange}
            className="hidden"
          />
          {imagePreview ? (
            <div className="relative w-full aspect-video rounded-lg overflow-hidden border border-white/10 group">
              <img src={imagePreview} alt="Preview" className="w-full h-full object-cover" />
              <button
                type="button"
                onClick={() => { setImageFile(null); setImagePreview(null); if (fileInputRef.current) fileInputRef.current.value = ""; }}
                className="absolute top-2 right-2 bg-black/70 rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <X className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="absolute bottom-2 right-2 bg-black/70 text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity"
              >
                Change
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="w-full aspect-video rounded-lg border-2 border-dashed border-white/10 hover:border-white/30 transition-colors flex flex-col items-center justify-center gap-3 bg-black/20 group"
            >
              <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center group-hover:bg-primary/10 transition-colors">
                <ImageIcon className="w-6 h-6 text-muted-foreground group-hover:text-primary transition-colors" />
              </div>
              <div className="text-center">
                <p className="text-sm font-medium text-muted-foreground group-hover:text-white transition-colors">Click to upload image</p>
                <p className="text-xs text-muted-foreground mt-1">PNG, JPG, GIF up to 5MB</p>
              </div>
              <div className="flex items-center gap-2 text-xs text-primary">
                <Upload className="w-3.5 h-3.5" /> Upload Photo
              </div>
            </button>
          )}
        </div>

        <div className="space-y-2">
          <Label>
            Price (USD) <span className="text-red-400">*</span>
          </Label>
          <div className="relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground font-medium">$</span>
            <Input
              type="number"
              step="0.01"
              min="0.01"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              placeholder="29.99"
              className="bg-black/50 border-white/10 pl-8"
              required
            />
          </div>
        </div>

        <div className="flex gap-3 pt-2">
          <Button
            type="button"
            variant="outline"
            className="border-white/10"
            onClick={() => setLocation(`/stores/${storeId}/products`)}
            disabled={isPending}
          >
            Cancel
          </Button>
          <Button
            type="submit"
            disabled={!isValid || isPending}
            className="flex-1 bg-primary text-black hover:bg-primary/90 font-semibold disabled:opacity-40"
          >
            {isPending ? (
              <span className="flex items-center gap-2">
                <span className="w-4 h-4 border-2 border-black/30 border-t-black rounded-full animate-spin" />
                {uploading ? "Uploading image..." : "Adding product..."}
              </span>
            ) : (
              "Add Product"
            )}
          </Button>
        </div>

        {!isValid && (
          <p className="text-xs text-center text-muted-foreground">
            Fill in all required fields <span className="text-red-400">*</span> to submit
          </p>
        )}
      </form>
    </div>
  );
}
