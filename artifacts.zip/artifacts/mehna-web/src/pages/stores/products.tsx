import { useParams, Link } from "wouter";
import { useListProducts, getListProductsQueryKey, useDeleteProduct } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { Plus, Trash2, Package, Tag } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";

export default function StoreProducts() {
  const params = useParams<{ storeId: string }>();
  const storeId = parseInt(params.storeId, 10);
  const { toast } = useToast();
  const qc = useQueryClient();

  const { data: products, isLoading } = useListProducts(storeId, {
    query: { enabled: !!storeId, queryKey: getListProductsQueryKey(storeId) },
  });

  const deleteProduct = useDeleteProduct();

  const handleDelete = (productId: number) => {
    if (!confirm("Remove this product?")) return;
    deleteProduct.mutate({ storeId, productId }, {
      onSuccess: () => {
        qc.invalidateQueries({ queryKey: getListProductsQueryKey(storeId) });
        toast({ title: "Product removed" });
      },
      onError: () => toast({ title: "Remove failed", variant: "destructive" }),
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Products</h1>
          <p className="text-muted-foreground mt-1">{products?.length ?? 0} products in this store.</p>
        </div>
        <Link href={`/stores/${storeId}/products/new`}>
          <Button className="bg-primary text-black hover:bg-primary/90 font-semibold">
            <Plus className="w-4 h-4 mr-2" /> Add Product
          </Button>
        </Link>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-40 w-full" />)}
        </div>
      ) : products?.length === 0 ? (
        <div className="flex flex-col items-center justify-center p-16 bg-card rounded-lg border border-dashed text-center">
          <div className="w-16 h-16 bg-primary/10 text-primary rounded-full flex items-center justify-center mb-4">
            <Package className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-semibold mb-2">No products yet</h3>
          <p className="text-muted-foreground mb-6 max-w-md">Add your first product with a name, description, image, and price.</p>
          <Link href={`/stores/${storeId}/products/new`}>
            <Button className="bg-primary text-black hover:bg-primary/90">
              <Plus className="w-4 h-4 mr-2" /> Add Your First Product
            </Button>
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {products?.map(product => (
            <Card key={product.id} className="bg-card hover:border-white/20 transition-colors group">
              <CardContent className="pt-4">
                {product.imageUrl && (
                  <div className="w-full aspect-video rounded-md overflow-hidden mb-3">
                    <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover" />
                  </div>
                )}
                {!product.imageUrl && (
                  <div className="w-full aspect-video rounded-md bg-white/5 flex items-center justify-center mb-3">
                    <Package className="w-8 h-8 text-muted-foreground" />
                  </div>
                )}
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-sm line-clamp-2">{product.name}</h3>
                    {product.description && (
                      <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{product.description}</p>
                    )}
                    <div className="flex items-center gap-2 mt-2">
                      <span className="text-primary font-bold">${product.price}</span>
                      {product.compareAtPrice && (
                        <span className="text-muted-foreground line-through text-xs">${product.compareAtPrice}</span>
                      )}
                    </div>
                    {product.category && (
                      <span className="mt-1 inline-flex text-xs bg-white/5 text-muted-foreground px-2 py-0.5 rounded-full items-center gap-1">
                        <Tag className="w-2.5 h-2.5" /> {product.category}
                      </span>
                    )}
                  </div>
                  <button
                    onClick={() => handleDelete(product.id)}
                    className="opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-red-400 flex-shrink-0 p-1"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
