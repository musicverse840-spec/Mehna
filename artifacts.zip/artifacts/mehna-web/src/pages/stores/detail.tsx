import { useState, useEffect } from "react";
import { useParams, Link, useLocation } from "wouter";
import { useGetStore, getGetStoreQueryKey, useGetStoreStats, getGetStoreStatsQueryKey, useListProducts, getListProductsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Package, ShoppingCart, TrendingUp, DollarSign, Plus, ArrowRight, Zap, CheckCircle, Clock, AlertCircle, ExternalLink } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

function StripeConnectCard({ storeId }: { storeId: number }) {
  const { toast } = useToast();
  const [status, setStatus] = useState<"not_connected" | "pending" | "active" | "loading">("loading");
  const [connecting, setConnecting] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem("token");
    fetch(`/api/stripe/connect/status/${storeId}`, {
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    })
      .then(r => r.json())
      .then((d: { status?: string }) => setStatus((d.status ?? "not_connected") as typeof status))
      .catch(() => setStatus("not_connected"));
  }, [storeId]);

  const handleConnect = async () => {
    setConnecting(true);
    const token = localStorage.getItem("token");
    try {
      const res = await fetch(`/api/stripe/connect/onboard/${storeId}`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      });
      const data = await res.json() as { url?: string; error?: string };
      if (data.url) {
        window.location.href = data.url;
      } else {
        toast({ title: "Stripe setup failed", description: data.error ?? "Please add your STRIPE_SECRET_KEY.", variant: "destructive" });
        setConnecting(false);
      }
    } catch {
      toast({ title: "Connection failed", variant: "destructive" });
      setConnecting(false);
    }
  };

  if (status === "loading") {
    return <Skeleton className="h-28 w-full" />;
  }

  if (status === "active") {
    return (
      <Card className="bg-green-950/30 border-green-500/30">
        <CardContent className="pt-5 flex items-center gap-4">
          <div className="w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center flex-shrink-0">
            <CheckCircle className="w-5 h-5 text-green-400" />
          </div>
          <div className="flex-1">
            <p className="font-semibold text-green-400">Stripe Payments Active</p>
            <p className="text-sm text-muted-foreground">Your store accepts payments. Mehna keeps 5%, you earn 95%.</p>
          </div>
          <a href="https://dashboard.stripe.com" target="_blank" rel="noreferrer">
            <Button variant="outline" size="sm" className="border-green-500/30 text-green-400 gap-1">
              Dashboard <ExternalLink className="w-3.5 h-3.5" />
            </Button>
          </a>
        </CardContent>
      </Card>
    );
  }

  if (status === "pending") {
    return (
      <Card className="bg-yellow-950/30 border-yellow-500/30">
        <CardContent className="pt-5 flex items-center gap-4">
          <div className="w-10 h-10 rounded-full bg-yellow-500/20 flex items-center justify-center flex-shrink-0">
            <Clock className="w-5 h-5 text-yellow-400" />
          </div>
          <div className="flex-1">
            <p className="font-semibold text-yellow-400">Stripe Onboarding In Progress</p>
            <p className="text-sm text-muted-foreground">Finish setting up your Stripe account to start accepting payments.</p>
          </div>
          <Button size="sm" onClick={handleConnect} disabled={connecting} className="bg-yellow-500 text-black hover:bg-yellow-400 font-semibold">
            {connecting ? "Opening..." : "Continue"}
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-card border-primary/30">
      <CardContent className="pt-5">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
            <Zap className="w-5 h-5 text-primary" />
          </div>
          <div className="flex-1">
            <p className="font-semibold">Connect Stripe to Accept Payments</p>
            <p className="text-sm text-muted-foreground">
              Receive payments directly to your bank. Mehna keeps 5% platform fee — you keep 95%.
            </p>
          </div>
          <Button onClick={handleConnect} disabled={connecting} className="bg-primary text-black hover:bg-primary/90 font-bold whitespace-nowrap">
            {connecting ? (
              <span className="flex items-center gap-2"><span className="w-4 h-4 border-2 border-black/30 border-t-black rounded-full animate-spin" /> Opening Stripe...</span>
            ) : (
              <span className="flex items-center gap-2"><Zap className="w-4 h-4" /> Connect Stripe</span>
            )}
          </Button>
        </div>
        <div className="mt-4 grid grid-cols-3 gap-3 text-center">
          {[
            { label: "Platform fee", value: "5%" },
            { label: "Your earnings", value: "95%" },
            { label: "Payout speed", value: "2 days" },
          ].map(item => (
            <div key={item.label} className="bg-black/20 rounded-lg py-2">
              <p className="text-base font-bold text-primary">{item.value}</p>
              <p className="text-xs text-muted-foreground">{item.label}</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

export default function StoreDetail() {
  const params = useParams<{ storeId: string }>();
  const storeId = parseInt(params.storeId, 10);
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  useEffect(() => {
    const p = new URLSearchParams(window.location.search);
    if (p.get("stripe_onboarded") === "1") {
      toast({ title: "Stripe connected!", description: "Your payment setup is being verified by Stripe." });
      setLocation(`/stores/${storeId}`, { replace: true });
    }
  }, []);

  const { data: store, isLoading: storeLoading } = useGetStore(storeId, {
    query: { enabled: !!storeId, queryKey: getGetStoreQueryKey(storeId) },
  });

  const { data: stats, isLoading: statsLoading } = useGetStoreStats(storeId, {
    query: { enabled: !!storeId, queryKey: getGetStoreStatsQueryKey(storeId) },
  });

  const { data: products } = useListProducts(storeId, {
    query: { enabled: !!storeId, queryKey: getListProductsQueryKey(storeId) },
  });

  const hasNoProducts = !products || products.length === 0;

  if (storeLoading) return <div className="space-y-4">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-24 w-full" />)}</div>;
  if (!store) return <div className="text-muted-foreground">Store not found.</div>;

  const statCards = [
    { label: "Total Orders", value: stats?.totalOrders ?? 0, icon: ShoppingCart },
    { label: "Revenue", value: `$${(stats?.totalRevenue ?? 0).toFixed(2)}`, icon: DollarSign },
    { label: "Products", value: stats?.totalProducts ?? 0, icon: Package },
    { label: "30-day Orders", value: stats?.recentOrders ?? 0, icon: TrendingUp },
  ];

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{store.name}</h1>
          <p className="text-muted-foreground mt-1">{store.description || "No description"}</p>
        </div>
        <div className="flex gap-2">
          <Link href={`/stores/${storeId}/orders`}>
            <Button variant="outline" className="border-white/10">
              <ShoppingCart className="w-4 h-4 mr-2" /> Orders
            </Button>
          </Link>
          <Link href={`/stores/${storeId}/products/new`}>
            <Button className="bg-primary text-black hover:bg-primary/90 font-semibold">
              <Plus className="w-4 h-4 mr-2" /> Add Product
            </Button>
          </Link>
        </div>
      </div>

      {hasNoProducts && (
        <Card className="bg-gradient-to-br from-primary/10 to-primary/5 border-primary/30">
          <CardContent className="pt-6">
            <div className="flex flex-col sm:flex-row items-center gap-6">
              <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                <Package className="w-8 h-8 text-primary" />
              </div>
              <div className="flex-1 text-center sm:text-left">
                <h3 className="text-lg font-bold mb-1">Add your first product</h3>
                <p className="text-muted-foreground text-sm">Your store is ready! Now add products with a name, description, photo, and price to start selling.</p>
              </div>
              <Link href={`/stores/${storeId}/products/new`}>
                <Button className="bg-primary text-black hover:bg-primary/90 font-semibold whitespace-nowrap">
                  <Plus className="w-4 h-4 mr-2" /> Add Product
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      )}

      <StripeConnectCard storeId={storeId} />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map(({ label, value, icon: Icon }) => (
          <Card key={label} className="bg-card">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <p className="text-sm text-muted-foreground">{label}</p>
                <div className="w-8 h-8 rounded bg-primary/10 text-primary flex items-center justify-center">
                  <Icon className="w-4 h-4" />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {statsLoading ? <Skeleton className="h-8 w-16" /> : <p className="text-2xl font-bold">{value}</p>}
            </CardContent>
          </Card>
        ))}
      </div>

      {stats && (
        <Card className="bg-card border-white/5">
          <CardContent className="pt-6">
            <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-4">Revenue Split</h3>
            <div className="flex items-center gap-4 flex-wrap">
              <div className="flex-1 min-w-[120px]">
                <p className="text-xs text-muted-foreground">Total Revenue</p>
                <p className="text-xl font-bold">${(stats.totalRevenue ?? 0).toFixed(2)}</p>
              </div>
              <div className="w-px h-8 bg-white/10 hidden sm:block" />
              <div className="flex-1 min-w-[120px]">
                <p className="text-xs text-muted-foreground">Platform Fee (5%)</p>
                <p className="text-xl font-bold text-yellow-500">${(stats.platformFee ?? 0).toFixed(2)}</p>
              </div>
              <div className="w-px h-8 bg-white/10 hidden sm:block" />
              <div className="flex-1 min-w-[120px]">
                <p className="text-xs text-muted-foreground">Your Earnings (95%)</p>
                <p className="text-xl font-bold text-green-400">${((stats.totalRevenue ?? 0) - (stats.platformFee ?? 0)).toFixed(2)}</p>
              </div>
              <div className="w-px h-8 bg-white/10 hidden sm:block" />
              <div className="flex-1 min-w-[120px]">
                <p className="text-xs text-muted-foreground">Conversion Rate</p>
                <p className="text-xl font-bold">{((stats.conversionRate ?? 0) * 100).toFixed(1)}%</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Link href={`/stores/${storeId}/products`}>
          <Card className="bg-card hover:border-primary/50 transition-colors cursor-pointer group">
            <CardContent className="pt-6 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded bg-primary/10 text-primary flex items-center justify-center">
                  <Package className="w-5 h-5" />
                </div>
                <div>
                  <p className="font-semibold">Manage Products</p>
                  <p className="text-sm text-muted-foreground">Add and manage your product catalog</p>
                </div>
              </div>
              <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
            </CardContent>
          </Card>
        </Link>
        <Link href={`/stores/${storeId}/orders`}>
          <Card className="bg-card hover:border-primary/50 transition-colors cursor-pointer group">
            <CardContent className="pt-6 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded bg-primary/10 text-primary flex items-center justify-center">
                  <ShoppingCart className="w-5 h-5" />
                </div>
                <div>
                  <p className="font-semibold">View Orders</p>
                  <p className="text-sm text-muted-foreground">Track orders and notify suppliers</p>
                </div>
              </div>
              <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
            </CardContent>
          </Card>
        </Link>
      </div>
    </div>
  );
}
