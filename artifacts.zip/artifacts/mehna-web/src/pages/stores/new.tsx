import { useState, useRef } from "react";
import { useLocation } from "wouter";
import { useCreateStore, useAiGenerateStore } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Sparkles, Store, Mic, MicOff } from "lucide-react";
import { cn } from "@/lib/utils";

export default function NewStore() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [mode, setMode] = useState<"ai" | "manual">("ai");
  const [prompt, setPrompt] = useState("");
  const [isListening, setIsListening] = useState(false);
  const [manualData, setManualData] = useState({ name: "", description: "", category: "", currency: "USD" });
  const recognitionRef = useRef<{ stop: () => void } | null>(null);

  const aiGenerate = useAiGenerateStore();
  const createStore = useCreateStore();

  const handleVoice = () => {
    if (!("webkitSpeechRecognition" in window || "SpeechRecognition" in window)) {
      toast({ title: "Voice not supported", description: "Use a modern browser for voice input.", variant: "destructive" });
      return;
    }
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      return;
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const SpeechRecognitionClass = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const recognition: any = new SpeechRecognitionClass();
    recognition.continuous = true;
    recognition.interimResults = true;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    recognition.onresult = (e: any) => {
      const transcript = Array.from(e.results as ArrayLike<{ [i: number]: { transcript: string } }>)
        .map((r) => r[0].transcript)
        .join(" ");
      setPrompt(transcript);
    };
    recognition.onend = () => setIsListening(false);
    recognition.start();
    recognitionRef.current = recognition;
    setIsListening(true);
  };

  const handleAiSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;
    aiGenerate.mutate({ data: { prompt } }, {
      onSuccess: (store) => {
        toast({ title: "Store created!", description: `${store.name} is ready.` });
        setLocation(`/stores/${store.id}`);
      },
      onError: () => toast({ title: "Failed to generate store", variant: "destructive" }),
    });
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createStore.mutate({ data: manualData }, {
      onSuccess: (store) => {
        toast({ title: "Store created!", description: `${store.name} is live.` });
        setLocation(`/stores/${store.id}`);
      },
      onError: () => toast({ title: "Failed to create store", variant: "destructive" }),
    });
  };

  return (
    <div className="max-w-3xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Create a Store</h1>
        <p className="text-muted-foreground mt-1">Launch your dropshipping business in seconds.</p>
      </div>

      <div className="flex gap-3">
        <button
          onClick={() => setMode("ai")}
          className={cn("flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-lg border font-semibold transition-all", mode === "ai" ? "bg-primary text-black border-primary" : "bg-transparent border-white/10 text-muted-foreground hover:border-white/30")}
        >
          <Sparkles className="w-4 h-4" /> AI Generate
        </button>
        <button
          onClick={() => setMode("manual")}
          className={cn("flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-lg border font-semibold transition-all", mode === "manual" ? "bg-primary text-black border-primary" : "bg-transparent border-white/10 text-muted-foreground hover:border-white/30")}
        >
          <Store className="w-4 h-4" /> Manual Setup
        </button>
      </div>

      {mode === "ai" ? (
        <form onSubmit={handleAiSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label className="text-base font-semibold">Describe your store idea</Label>
            <p className="text-sm text-muted-foreground">Tell the AI what you want to sell, who your audience is, and the vibe you're going for.</p>
            <div className="relative">
              <Textarea
                value={prompt}
                onChange={e => setPrompt(e.target.value)}
                placeholder="e.g. A premium fitness gear store targeting gym enthusiasts aged 20-35 who care about performance and aesthetics. Focus on resistance bands, gym bags, and supplement accessories."
                className="min-h-[160px] resize-none bg-black/50 border-white/10 pr-12 text-base leading-relaxed"
                required
              />
              <button
                type="button"
                onClick={handleVoice}
                className={cn("absolute bottom-3 right-3 p-2 rounded-lg transition-colors", isListening ? "bg-red-500 text-white animate-pulse" : "bg-white/10 hover:bg-white/20 text-muted-foreground")}
              >
                {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              </button>
            </div>
            {isListening && <p className="text-xs text-red-400 flex items-center gap-1"><span className="w-2 h-2 bg-red-400 rounded-full animate-pulse inline-block" /> Listening...</p>}
          </div>
          <Button type="submit" disabled={aiGenerate.isPending || !prompt.trim()} className="w-full bg-primary text-black hover:bg-primary/90 font-bold h-12 text-base">
            {aiGenerate.isPending ? (
              <span className="flex items-center gap-2"><span className="w-4 h-4 border-2 border-black/30 border-t-black rounded-full animate-spin" /> Building your store...</span>
            ) : (
              <span className="flex items-center gap-2"><Sparkles className="w-5 h-5" /> Generate Store with AI</span>
            )}
          </Button>
        </form>
      ) : (
        <form onSubmit={handleManualSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label>Store Name</Label>
            <Input value={manualData.name} onChange={e => setManualData(d => ({ ...d, name: e.target.value }))} placeholder="My Awesome Store" className="bg-black/50 border-white/10" required />
          </div>
          <div className="space-y-2">
            <Label>Description</Label>
            <Textarea value={manualData.description} onChange={e => setManualData(d => ({ ...d, description: e.target.value }))} placeholder="What do you sell?" className="bg-black/50 border-white/10" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Category</Label>
              <Input value={manualData.category} onChange={e => setManualData(d => ({ ...d, category: e.target.value }))} placeholder="e.g. Electronics" className="bg-black/50 border-white/10" />
            </div>
            <div className="space-y-2">
              <Label>Currency</Label>
              <Input value={manualData.currency} onChange={e => setManualData(d => ({ ...d, currency: e.target.value }))} placeholder="USD" className="bg-black/50 border-white/10" />
            </div>
          </div>
          <Button type="submit" disabled={createStore.isPending} className="w-full bg-primary text-black hover:bg-primary/90 font-bold h-12">
            {createStore.isPending ? "Creating..." : "Create Store"}
          </Button>
        </form>
      )}
    </div>
  );
}
