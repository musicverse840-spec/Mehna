import { useParams, Link } from "wouter";
import { useListOrders, getListOrdersQueryKey } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { ShoppingCart, ChevronRight, CheckCircle2, Clock, Truck, XCircle, AlertCircle } from "lucide-react";

const STATUS_MAP: Record<string, { label: string; color: string; icon: typeof Clock }> = {
  pending: { label: "Pending", color: "text-yellow-400 bg-yellow-400/10", icon: Clock },
  confirmed: { label: "Confirmed", color: "text-blue-400 bg-blue-400/10", icon: CheckCircle2 },
  processing: { label: "Processing", color: "text-purple-400 bg-purple-400/10", icon: AlertCircle },
  shipped: { label: "Shipped", color: "text-primary bg-primary/10", icon: Truck },
  delivered: { label: "Delivered", color: "text-green-400 bg-green-400/10", icon: CheckCircle2 },
  cancelled: { label: "Cancelled", color: "text-red-400 bg-red-400/10", icon: XCircle },
};

export default function StoreOrders() {
  const params = useParams<{ storeId: string }>();
  const storeId = parseInt(params.storeId, 10);

  const { data: orders, isLoading } = useListOrders(storeId, {
    query: { enabled: !!storeId, queryKey: getListOrdersQueryKey(storeId) },
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Orders</h1>
        <p className="text-muted-foreground mt-1">{orders?.length ?? 0} orders total.</p>
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-20 w-full" />)}
        </div>
      ) : orders?.length === 0 ? (
        <div className="flex flex-col items-center justify-center p-16 bg-card rounded-lg border border-dashed text-center">
          <div className="w-16 h-16 bg-primary/10 text-primary rounded-full flex items-center justify-center mb-4">
            <ShoppingCart className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-semibold mb-2">No orders yet</h3>
          <p className="text-muted-foreground max-w-md">When customers purchase from your store, orders will appear here.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {orders?.map(order => {
            const status = STATUS_MAP[order.status] ?? STATUS_MAP.pending;
            const StatusIcon = status.icon;
            return (
              <Link key={order.id} href={`/stores/${storeId}/orders/${order.id}`}>
                <Card className="bg-card hover:border-white/20 transition-colors cursor-pointer group">
                  <CardContent className="pt-4 pb-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-semibold text-sm">Order #{order.id}</span>
                            <span className={`text-xs px-2 py-0.5 rounded-full flex items-center gap-1 font-medium ${status.color}`}>
                              <StatusIcon className="w-3 h-3" /> {status.label}
                            </span>
                            {order.supplierNotified && (
                              <span className="text-xs px-2 py-0.5 rounded-full bg-green-400/10 text-green-400 font-medium">Supplier Notified</span>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground">{order.customerName} · {order.customerEmail}</p>
                          <p className="text-xs text-muted-foreground mt-1">{new Date(order.createdAt).toLocaleDateString()}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <p className="font-bold">${order.total.toFixed(2)}</p>
                          <p className="text-xs text-muted-foreground">You earn ${order.ownerAmount.toFixed(2)}</p>
                        </div>
                        <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-foreground transition-colors" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
