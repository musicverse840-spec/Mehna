import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";

const plans = [
  {
    name: "Free",
    price: "$0",
    interval: "month",
    features: ["1 product", "1 store", "Basic support"],
  },
  {
    name: "Monthly",
    price: "$21",
    interval: "month",
    popular: true,
    features: ["5 stores", "Unlimited products", "Priority support", "AI Assistant"],
  },
  {
    name: "Annual",
    price: "$199",
    interval: "year",
    features: ["17 stores", "Unlimited products", "Priority support", "AI Assistant", "Save 20%"],
  }
];

export default function Pricing() {
  return (
    <div className="space-y-8 pb-12">
      <div className="text-center max-w-2xl mx-auto mb-12">
        <h1 className="text-4xl font-extrabold tracking-tight mb-4">Simple, transparent pricing</h1>
        <p className="text-lg text-muted-foreground">Invest in your dropshipping empire. 5% platform fee on all sales.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
        {plans.map((plan) => (
          <Card key={plan.name} className={`relative bg-card flex flex-col ${plan.popular ? 'border-primary shadow-lg shadow-primary/10' : ''}`}>
            {plan.popular && (
              <div className="absolute -top-3 left-0 right-0 flex justify-center">
                <span className="bg-primary text-black text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                  Most Popular
                </span>
              </div>
            )}
            <CardHeader className="text-center pb-8 pt-8">
              <CardTitle className="text-2xl mb-2">{plan.name}</CardTitle>
              <div className="flex justify-center items-baseline">
                <span className="text-5xl font-extrabold">{plan.price}</span>
                <span className="text-muted-foreground ml-1">/{plan.interval}</span>
              </div>
            </CardHeader>
            <CardContent className="flex-1">
              <ul className="space-y-4">
                {plan.features.map((feature, i) => (
                  <li key={i} className="flex items-center">
                    <Check className="w-5 h-5 text-primary mr-3 flex-shrink-0" />
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
            <CardFooter>
              <Button className={`w-full ${plan.popular ? 'bg-primary text-black hover:bg-primary/90' : ''}`} variant={plan.popular ? 'default' : 'outline'}>
                {plan.price === "$0" ? "Current Plan" : "Upgrade"}
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
}
