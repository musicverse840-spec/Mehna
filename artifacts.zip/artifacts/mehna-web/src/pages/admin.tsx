import { useGetAdminStats, getGetAdminStatsQueryKey, useListAdminUsers, getListAdminUsersQueryKey, useUpdateAdminUser } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { Users, Store, ShoppingCart, DollarSign, TrendingUp, Shield, Ban, CheckCircle } from "lucide-react";
import { useState } from "react";

export default function Admin() {
  const { data: stats, isLoading: statsLoading } = useGetAdminStats({
    query: { queryKey: getGetAdminStatsQueryKey() },
  });

  const [search, setSearch] = useState("");
  const { data: users, isLoading: usersLoading } = useListAdminUsers({ search: search || undefined }, {
    query: { queryKey: getListAdminUsersQueryKey({ search: search || undefined }) },
  });

  const { toast } = useToast();
  const qc = useQueryClient();
  const updateUser = useUpdateAdminUser();

  const toggleBlock = (userId: number, isBlocked: boolean) => {
    updateUser.mutate({ userId, data: { isBlocked: !isBlocked } }, {
      onSuccess: () => {
        qc.invalidateQueries({ queryKey: getListAdminUsersQueryKey({}) });
        toast({ title: !isBlocked ? "User blocked" : "User unblocked" });
      },
      onError: () => toast({ title: "Failed to update user", variant: "destructive" }),
    });
  };

  const statCards = [
    { label: "Total Users", value: stats?.totalUsers, icon: Users },
    { label: "Total Stores", value: stats?.totalStores, icon: Store },
    { label: "Total Orders", value: stats?.totalOrders, icon: ShoppingCart },
    { label: "Total Revenue", value: stats?.totalRevenue ? `$${stats.totalRevenue.toFixed(2)}` : "$0.00", icon: DollarSign },
    { label: "Platform Fees", value: stats?.platformFeeCollected ? `$${stats.platformFeeCollected.toFixed(2)}` : "$0.00", icon: TrendingUp },
    { label: "Active Subs", value: stats?.activeSubscriptions, icon: Shield },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Admin Dashboard</h1>
        <p className="text-muted-foreground mt-1">Platform-wide metrics and user management.</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {statCards.map(({ label, value, icon: Icon }) => (
          <Card key={label} className="bg-card">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <p className="text-xs text-muted-foreground">{label}</p>
                <div className="w-7 h-7 rounded bg-primary/10 text-primary flex items-center justify-center">
                  <Icon className="w-3.5 h-3.5" />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {statsLoading ? <Skeleton className="h-7 w-16" /> : <p className="text-xl font-bold">{value ?? 0}</p>}
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold">Users</h2>
          <div className="relative w-64">
            <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search users..." className="bg-black/50 border-white/10" />
          </div>
        </div>

        <div className="overflow-x-auto rounded-lg border border-white/10">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-white/10 bg-white/2">
                <th className="text-left p-3 text-muted-foreground font-medium">User</th>
                <th className="text-left p-3 text-muted-foreground font-medium">Plan</th>
                <th className="text-left p-3 text-muted-foreground font-medium">Stores</th>
                <th className="text-left p-3 text-muted-foreground font-medium">Orders</th>
                <th className="text-left p-3 text-muted-foreground font-medium">Revenue</th>
                <th className="text-left p-3 text-muted-foreground font-medium">Status</th>
                <th className="text-left p-3 text-muted-foreground font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {usersLoading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <tr key={i} className="border-b border-white/5">
                    {Array.from({ length: 7 }).map((_, j) => (
                      <td key={j} className="p-3"><Skeleton className="h-5 w-full" /></td>
                    ))}
                  </tr>
                ))
              ) : (
                users?.map(user => (
                  <tr key={user.id} className="border-b border-white/5 hover:bg-white/2 transition-colors">
                    <td className="p-3">
                      <div>
                        <p className="font-medium">{user.name}</p>
                        <p className="text-xs text-muted-foreground">{user.email}</p>
                      </div>
                    </td>
                    <td className="p-3">
                      <span className="text-xs px-2 py-0.5 bg-primary/10 text-primary rounded-full">{user.planName ?? "Free"}</span>
                    </td>
                    <td className="p-3">{user.storeCount}</td>
                    <td className="p-3">{user.orderCount}</td>
                    <td className="p-3">${user.totalRevenue?.toFixed(2) ?? "0.00"}</td>
                    <td className="p-3">
                      {user.isBlocked ? (
                        <span className="text-xs px-2 py-0.5 bg-red-400/10 text-red-400 rounded-full">Blocked</span>
                      ) : (
                        <span className="text-xs px-2 py-0.5 bg-green-400/10 text-green-400 rounded-full">Active</span>
                      )}
                    </td>
                    <td className="p-3">
                      {user.role !== "admin" && (
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => toggleBlock(user.id, user.isBlocked ?? false)}
                          className={user.isBlocked ? "text-green-400 hover:text-green-300" : "text-red-400 hover:text-red-300"}
                        >
                          {user.isBlocked ? <CheckCircle className="w-4 h-4" /> : <Ban className="w-4 h-4" />}
                        </Button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
