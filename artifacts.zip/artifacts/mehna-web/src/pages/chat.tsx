import { useState, useRef, useEffect } from "react";
import {
  useListOpenaiConversations, getListOpenaiConversationsQueryKey,
  useCreateOpenaiConversation, useDeleteOpenaiConversation,
  useListOpenaiMessages, getListOpenaiMessagesQueryKey,
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { Send, Plus, Trash2, Mic, MicOff, Bot, User, MessageSquare } from "lucide-react";
import { cn } from "@/lib/utils";

interface Message {
  role: "user" | "assistant";
  content: string;
  streaming?: boolean;
}

export default function Chat() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [activeConvoId, setActiveConvoId] = useState<number | null>(null);
  const [input, setInput] = useState("");
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamingMessages, setStreamingMessages] = useState<Message[]>([]);
  const [isListening, setIsListening] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const recognitionRef = useRef<any>(null);

  const { data: conversations, isLoading: convosLoading } = useListOpenaiConversations({
    query: { queryKey: getListOpenaiConversationsQueryKey() },
  });

  const { data: messages, isLoading: msgsLoading } = useListOpenaiMessages(activeConvoId ?? 0, {
    query: { enabled: !!activeConvoId, queryKey: getListOpenaiMessagesQueryKey(activeConvoId ?? 0) },
  });

  const createConvo = useCreateOpenaiConversation();
  const deleteConvo = useDeleteOpenaiConversation();

  useEffect(() => {
    if (messages) {
      setStreamingMessages(messages.map(m => ({ role: m.role as "user" | "assistant", content: m.content })));
    }
  }, [messages]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [streamingMessages]);

  const startNewConversation = () => {
    const title = `Chat ${new Date().toLocaleDateString()}`;
    createConvo.mutate({ data: { title } }, {
      onSuccess: (convo) => {
        qc.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() });
        setActiveConvoId(convo.id);
        setStreamingMessages([]);
      },
      onError: () => toast({ title: "Failed to create conversation", variant: "destructive" }),
    });
  };

  const handleDeleteConvo = (id: number, e: React.MouseEvent) => {
    e.stopPropagation();
    deleteConvo.mutate({ id }, {
      onSuccess: () => {
        qc.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() });
        if (activeConvoId === id) {
          setActiveConvoId(null);
          setStreamingMessages([]);
        }
      },
    });
  };

  const sendMessage = async () => {
    if (!input.trim() || !activeConvoId || isStreaming) return;

    const userMessage = input.trim();
    setInput("");
    setStreamingMessages(prev => [...prev, { role: "user", content: userMessage }]);
    setIsStreaming(true);

    const assistantMsg: Message = { role: "assistant", content: "", streaming: true };
    setStreamingMessages(prev => [...prev, assistantMsg]);

    try {
      const token = localStorage.getItem("token");
      const response = await fetch(`/api/openai/conversations/${activeConvoId}/messages`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({ content: userMessage }),
      });

      if (!response.ok) throw new Error("Stream failed");

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      if (!reader) throw new Error("No reader");

      let fullContent = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value);
        const lines = chunk.split("\n").filter(l => l.startsWith("data: "));

        for (const line of lines) {
          try {
            const data = JSON.parse(line.slice(6)) as { content?: string; done?: boolean };
            if (data.done) break;
            if (data.content) {
              fullContent += data.content;
              const fc = fullContent;
              setStreamingMessages(prev => {
                const updated = [...prev];
                const lastMsg = updated[updated.length - 1];
                if (lastMsg?.role === "assistant") {
                  updated[updated.length - 1] = { ...lastMsg, content: fc, streaming: true };
                }
                return updated;
              });
            }
          } catch { /* ignore parse errors */ }
        }
      }

      setStreamingMessages(prev => {
        const updated = [...prev];
        const lastMsg = updated[updated.length - 1];
        if (lastMsg?.role === "assistant") {
          updated[updated.length - 1] = { ...lastMsg, streaming: false };
        }
        return updated;
      });

      qc.invalidateQueries({ queryKey: getListOpenaiMessagesQueryKey(activeConvoId) });
    } catch (err) {
      if ((err as Error).name !== "AbortError") {
        toast({ title: "Message failed", variant: "destructive" });
        setStreamingMessages(prev => prev.filter(m => !(m.role === "assistant" && m.streaming)));
      }
    } finally {
      setIsStreaming(false);
    }
  };

  const handleVoice = () => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const win = window as any;
    if (!win.SpeechRecognition && !win.webkitSpeechRecognition) {
      toast({ title: "Voice not supported", description: "Use a modern browser.", variant: "destructive" });
      return;
    }
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      return;
    }
    const SpeechRecognitionClass = win.SpeechRecognition || win.webkitSpeechRecognition;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const r: any = new SpeechRecognitionClass();
    r.continuous = true;
    r.interimResults = true;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    r.onresult = (e: any) => {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const t = Array.from(e.results as any[]).map((res: any) => res[0].transcript).join(" ");
      setInput(t);
    };
    r.onend = () => setIsListening(false);
    r.start();
    recognitionRef.current = r;
    setIsListening(true);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      void sendMessage();
    }
  };

  return (
    <div className="flex h-[calc(100vh-72px)] -mx-4 -my-6 overflow-hidden">
      {/* Sidebar */}
      <div className="w-60 flex-shrink-0 border-r border-white/5 bg-black/40 flex flex-col">
        <div className="p-3 border-b border-white/5">
          <Button onClick={startNewConversation} disabled={createConvo.isPending} className="w-full bg-primary text-black hover:bg-primary/90 font-semibold" size="sm">
            <Plus className="w-4 h-4 mr-2" /> New Chat
          </Button>
        </div>
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {convosLoading ? (
            Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)
          ) : !conversations?.length ? (
            <p className="text-xs text-muted-foreground text-center py-4">No conversations yet.</p>
          ) : (
            conversations.map(convo => (
              <div
                key={convo.id}
                onClick={() => { setActiveConvoId(convo.id); setStreamingMessages([]); }}
                className={cn(
                  "flex items-center justify-between px-3 py-2 rounded cursor-pointer group transition-colors text-sm",
                  activeConvoId === convo.id ? "bg-primary/15 text-foreground" : "hover:bg-white/5 text-muted-foreground"
                )}
              >
                <div className="flex items-center gap-2 min-w-0">
                  <MessageSquare className="w-3.5 h-3.5 flex-shrink-0" />
                  <span className="truncate">{convo.title}</span>
                </div>
                <button
                  onClick={(e) => handleDeleteConvo(convo.id, e)}
                  className="opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-red-400 flex-shrink-0 ml-1"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Main area */}
      <div className="flex-1 flex flex-col min-w-0">
        {!activeConvoId ? (
          <div className="flex-1 flex flex-col items-center justify-center gap-6 text-center px-8">
            <div className="w-16 h-16 rounded-full bg-primary/15 text-primary flex items-center justify-center">
              <Bot className="w-8 h-8" />
            </div>
            <div>
              <h2 className="text-2xl font-bold mb-2">Mehna AI Assistant</h2>
              <p className="text-muted-foreground max-w-md">Your expert dropshipping advisor. Get help with product research, store optimization, marketing strategies, and more.</p>
            </div>
            <Button onClick={startNewConversation} disabled={createConvo.isPending} className="bg-primary text-black hover:bg-primary/90 font-semibold">
              <Plus className="w-4 h-4 mr-2" /> Start a conversation
            </Button>
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {msgsLoading ? (
                <div className="space-y-4">
                  {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-16 w-3/4" />)}
                </div>
              ) : !streamingMessages.length ? (
                <div className="flex flex-col items-center justify-center h-full text-center">
                  <Bot className="w-10 h-10 text-primary mb-3" />
                  <p className="text-muted-foreground text-sm">Ask anything about dropshipping, products, marketing, or growing your business.</p>
                </div>
              ) : (
                streamingMessages.map((msg, i) => (
                  <div key={i} className={cn("flex gap-3 max-w-4xl", msg.role === "user" ? "ml-auto flex-row-reverse" : "")}>
                    <div className={cn("w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0", msg.role === "assistant" ? "bg-primary text-black" : "bg-white/10 text-foreground")}>
                      {msg.role === "assistant" ? <Bot className="w-4 h-4" /> : <User className="w-4 h-4" />}
                    </div>
                    <div className={cn("rounded-2xl px-4 py-3 text-sm max-w-[80%] leading-relaxed", msg.role === "assistant" ? "bg-card border border-white/5" : "bg-primary/15 border border-primary/20")}>
                      <div className="whitespace-pre-wrap">{msg.content}</div>
                      {msg.streaming && (
                        <span className="inline-block w-2 h-4 ml-0.5 bg-primary animate-pulse rounded-sm align-middle" />
                      )}
                    </div>
                  </div>
                ))
              )}
              <div ref={messagesEndRef} />
            </div>

            <div className="p-4 border-t border-white/5 bg-black/20">
              <div className="flex gap-2 items-center">
                <Input
                  value={input}
                  onChange={e => setInput(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="Ask about products, suppliers, marketing..."
                  className="bg-black/50 border-white/10"
                  disabled={isStreaming}
                />
                <Button type="button" size="icon" variant="ghost" onClick={handleVoice}
                  className={cn("flex-shrink-0", isListening ? "text-red-400 animate-pulse" : "text-muted-foreground hover:text-foreground")}
                >
                  {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                </Button>
                <Button onClick={() => void sendMessage()} disabled={!input.trim() || isStreaming}
                  className="bg-primary text-black hover:bg-primary/90 font-semibold flex-shrink-0" size="icon"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
              {isStreaming && <p className="text-xs text-muted-foreground mt-2">Mehna AI is thinking...</p>}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
