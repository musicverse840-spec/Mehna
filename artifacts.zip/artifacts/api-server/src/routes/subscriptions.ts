import { Router } from "express";
import { db } from "@workspace/db";
import { plansTable, subscriptionsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth } from "../lib/auth";
import { CreateSubscriptionCheckoutBody } from "@workspace/api-zod";

const router = Router();

router.get("/subscriptions/plans", async (_req, res): Promise<void> => {
  const plans = await db.select().from(plansTable);
  res.json(plans);
});

router.get("/subscriptions/current", requireAuth, async (req, res): Promise<void> => {
  const user = (req as typeof req & { user: { id: number } }).user;
  const [sub] = await db.select().from(subscriptionsTable).where(eq(subscriptionsTable.userId, user.id));

  if (!sub) {
    const [freePlan] = await db.select().from(plansTable).where(eq(plansTable.name, "Free"));
    res.json({
      id: 0,
      userId: user.id,
      planId: freePlan?.id ?? 1,
      planName: "Free",
      status: "free",
      currentPeriodEnd: null,
      stripeSubscriptionId: null,
      createdAt: new Date().toISOString(),
    });
    return;
  }

  const [plan] = await db.select().from(plansTable).where(eq(plansTable.id, sub.planId));
  res.json({
    id: sub.id,
    userId: sub.userId,
    planId: sub.planId,
    planName: plan?.name ?? "Unknown",
    status: sub.status,
    currentPeriodEnd: sub.currentPeriodEnd?.toISOString() ?? null,
    stripeSubscriptionId: sub.stripeSubscriptionId ?? null,
    createdAt: sub.createdAt.toISOString(),
  });
});

router.post("/subscriptions/checkout", requireAuth, async (req, res): Promise<void> => {
  const parsed = CreateSubscriptionCheckoutBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const [plan] = await db.select().from(plansTable).where(eq(plansTable.id, parsed.data.planId));
  if (!plan) { res.status(404).json({ error: "Plan not found" }); return; }

  if (!process.env.STRIPE_SECRET_KEY) {
    res.json({ url: `/pricing?plan=${plan.id}&status=stripe_not_configured` });
    return;
  }

  res.json({ url: `/pricing?plan=${plan.id}&status=checkout_pending` });
});

router.post("/subscriptions/cancel", requireAuth, async (req, res): Promise<void> => {
  const user = (req as typeof req & { user: { id: number } }).user;
  const [sub] = await db.update(subscriptionsTable)
    .set({ status: "cancelled" })
    .where(eq(subscriptionsTable.userId, user.id))
    .returning();

  if (!sub) { res.status(404).json({ error: "Subscription not found" }); return; }
  const [plan] = await db.select().from(plansTable).where(eq(plansTable.id, sub.planId));

  res.json({ ...sub, planName: plan?.name ?? "Unknown", currentPeriodEnd: sub.currentPeriodEnd?.toISOString() ?? null });
});

router.post("/subscriptions/webhook", async (req, res): Promise<void> => {
  res.json({ received: true });
});

export default router;
