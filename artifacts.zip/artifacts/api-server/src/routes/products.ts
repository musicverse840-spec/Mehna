import { Router } from "express";
import { db } from "@workspace/db";
import { productsTable, storesTable, subscriptionsTable, plansTable } from "@workspace/db";
import { eq, and, count } from "drizzle-orm";
import { requireAuth } from "../lib/auth";
import { ListProductsParams, CreateProductParams, CreateProductBody, GetProductParams, UpdateProductParams, UpdateProductBody, DeleteProductParams } from "@workspace/api-zod";
import multer from "multer";
import path from "node:path";
import fs from "node:fs";
import crypto from "node:crypto";

const router = Router();
function intParam(p: unknown): number { return parseInt(String(Array.isArray(p) ? p[0] : p), 10); }

const uploadsDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadsDir),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const name = `${Date.now()}-${crypto.randomBytes(8).toString("hex")}${ext}`;
    cb(null, name);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (file.mimetype.startsWith("image/")) cb(null, true);
    else cb(new Error("Only image files allowed"));
  },
});

router.post("/stores/:storeId/products/upload-image", requireAuth, upload.single("image"), async (req, res): Promise<void> => {
  if (!req.file) { res.status(400).json({ error: "No image file provided" }); return; }
  const url = `/api/uploads/${req.file.filename}`;
  res.json({ url });
});

router.get("/stores/:storeId/products", requireAuth, async (req, res): Promise<void> => {
  const user = (req as typeof req & { user: { id: number } }).user;
  const params = ListProductsParams.safeParse({ storeId: intParam(req.params.storeId) });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }

  const [store] = await db.select().from(storesTable).where(and(eq(storesTable.id, params.data.storeId), eq(storesTable.userId, user.id)));
  if (!store) { res.status(404).json({ error: "Store not found" }); return; }

  const products = await db.select().from(productsTable).where(eq(productsTable.storeId, params.data.storeId));
  res.json(products);
});

router.post("/stores/:storeId/products", requireAuth, async (req, res): Promise<void> => {
  const user = (req as typeof req & { user: { id: number } }).user;
  const params = CreateProductParams.safeParse({ storeId: intParam(req.params.storeId) });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }

  const parsed = CreateProductBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const [store] = await db.select().from(storesTable).where(and(eq(storesTable.id, params.data.storeId), eq(storesTable.userId, user.id)));
  if (!store) { res.status(404).json({ error: "Store not found" }); return; }

  const canCreate = await checkProductLimit(user.id, params.data.storeId);
  if (!canCreate) { res.status(403).json({ error: "Product limit reached. Upgrade your plan to add more products." }); return; }

  const [product] = await db.insert(productsTable).values({ ...parsed.data, storeId: params.data.storeId }).returning();
  res.status(201).json(product);
});

router.get("/stores/:storeId/products/:productId", requireAuth, async (req, res): Promise<void> => {
  const user = (req as typeof req & { user: { id: number } }).user;
  const params = GetProductParams.safeParse({ storeId: intParam(req.params.storeId), productId: intParam(req.params.productId) });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }

  const [store] = await db.select().from(storesTable).where(and(eq(storesTable.id, params.data.storeId), eq(storesTable.userId, user.id)));
  if (!store) { res.status(404).json({ error: "Store not found" }); return; }

  const [product] = await db.select().from(productsTable)
    .where(and(eq(productsTable.id, params.data.productId), eq(productsTable.storeId, params.data.storeId)));
  if (!product) { res.status(404).json({ error: "Product not found" }); return; }
  res.json(product);
});

router.patch("/stores/:storeId/products/:productId", requireAuth, async (req, res): Promise<void> => {
  const user = (req as typeof req & { user: { id: number } }).user;
  const params = UpdateProductParams.safeParse({ storeId: intParam(req.params.storeId), productId: intParam(req.params.productId) });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }

  const parsed = UpdateProductBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const [store] = await db.select().from(storesTable).where(and(eq(storesTable.id, params.data.storeId), eq(storesTable.userId, user.id)));
  if (!store) { res.status(404).json({ error: "Store not found" }); return; }

  const [product] = await db.update(productsTable)
    .set(parsed.data)
    .where(and(eq(productsTable.id, params.data.productId), eq(productsTable.storeId, params.data.storeId)))
    .returning();
  if (!product) { res.status(404).json({ error: "Product not found" }); return; }
  res.json(product);
});

router.delete("/stores/:storeId/products/:productId", requireAuth, async (req, res): Promise<void> => {
  const user = (req as typeof req & { user: { id: number } }).user;
  const params = DeleteProductParams.safeParse({ storeId: intParam(req.params.storeId), productId: intParam(req.params.productId) });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }

  const [store] = await db.select().from(storesTable).where(and(eq(storesTable.id, params.data.storeId), eq(storesTable.userId, user.id)));
  if (!store) { res.status(404).json({ error: "Store not found" }); return; }

  const [product] = await db.delete(productsTable)
    .where(and(eq(productsTable.id, params.data.productId), eq(productsTable.storeId, params.data.storeId)))
    .returning();
  if (!product) { res.status(404).json({ error: "Product not found" }); return; }
  res.sendStatus(204);
});

async function checkProductLimit(userId: number, storeId: number): Promise<boolean> {
  const [sub] = await db.select({ planId: subscriptionsTable.planId }).from(subscriptionsTable).where(eq(subscriptionsTable.userId, userId));
  const planId = sub?.planId ?? null;
  const [plan] = planId ? await db.select().from(plansTable).where(eq(plansTable.id, planId)) : [];
  const maxProducts = plan?.maxProducts ?? 1;
  const [cnt] = await db.select({ c: count() }).from(productsTable).where(eq(productsTable.storeId, storeId));
  return (cnt?.c ?? 0) < maxProducts;
}

export default router;
