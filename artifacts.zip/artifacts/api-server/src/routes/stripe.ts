import { Router, type Request, type Response } from "express";
import Stripe from "stripe";
import { db } from "@workspace/db";
import { storesTable, ordersTable, orderItemsTable, productsTable } from "@workspace/db";
import { eq, and, inArray } from "drizzle-orm";
import { requireAuth } from "../lib/auth";

const router = Router();

function getStripe(): Stripe {
  const key = process.env["STRIPE_SECRET_KEY"];
  if (!key) throw new Error("STRIPE_SECRET_KEY not set");
  return new Stripe(key, { apiVersion: "2025-04-30.basil" });
}

function getAppUrl(): string {
  const domains = process.env["REPLIT_DOMAINS"];
  if (domains) return `https://${domains.split(",")[0].trim()}`;
  return process.env["APP_URL"] ?? "http://localhost";
}

const PLATFORM_FEE_PERCENT = 0.05;

// ─── Onboard store to Stripe Connect ──────────────────────────────────────────

router.post("/stripe/connect/onboard/:storeId", requireAuth, async (req: Request, res: Response): Promise<void> => {
  const user = (req as typeof req & { user: { id: number } }).user;
  const storeId = parseInt(req.params.storeId, 10);

  const [store] = await db.select().from(storesTable).where(
    and(eq(storesTable.id, storeId), eq(storesTable.userId, user.id))
  );
  if (!store) { res.status(404).json({ error: "Store not found" }); return; }

  try {
    const stripe = getStripe();
    let accountId = store.stripeAccountId;

    if (!accountId) {
      const account = await stripe.accounts.create({
        type: "express",
        capabilities: { card_payments: { requested: true }, transfers: { requested: true } },
        business_type: "individual",
        metadata: { storeId: String(storeId), userId: String(user.id) },
      });
      accountId = account.id;
      await db.update(storesTable)
        .set({ stripeAccountId: accountId, stripeAccountStatus: "pending" })
        .where(eq(storesTable.id, storeId));
    }

    const link = await stripe.accountLinks.create({
      account: accountId,
      refresh_url: `${getAppUrl()}/api/stripe/connect/onboard/${storeId}`,
      return_url: `${getAppUrl()}/api/stripe/connect/return/${storeId}`,
      type: "account_onboarding",
    });

    res.json({ url: link.url });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Stripe error";
    if (msg.includes("STRIPE_SECRET_KEY")) {
      res.status(503).json({ error: "Stripe is not configured. Add STRIPE_SECRET_KEY to your secrets." });
    } else {
      res.status(500).json({ error: msg });
    }
  }
});

// ─── Return URL after onboarding ──────────────────────────────────────────────

router.get("/stripe/connect/return/:storeId", async (req: Request, res: Response): Promise<void> => {
  const storeId = parseInt(req.params.storeId, 10);
  const [store] = await db.select().from(storesTable).where(eq(storesTable.id, storeId));

  if (store?.stripeAccountId) {
    try {
      const stripe = getStripe();
      const account = await stripe.accounts.retrieve(store.stripeAccountId);
      const status = account.charges_enabled ? "active" : "pending";
      await db.update(storesTable).set({ stripeAccountStatus: status }).where(eq(storesTable.id, storeId));
    } catch {
      /* ignore */
    }
  }

  res.redirect(`/stores/${storeId}?stripe_onboarded=1`);
});

// ─── Get Stripe Connect status for a store ────────────────────────────────────

router.get("/stripe/connect/status/:storeId", requireAuth, async (req: Request, res: Response): Promise<void> => {
  const user = (req as typeof req & { user: { id: number } }).user;
  const storeId = parseInt(req.params.storeId, 10);

  const [store] = await db.select().from(storesTable).where(
    and(eq(storesTable.id, storeId), eq(storesTable.userId, user.id))
  );
  if (!store) { res.status(404).json({ error: "Store not found" }); return; }

  if (store.stripeAccountId) {
    try {
      const stripe = getStripe();
      const account = await stripe.accounts.retrieve(store.stripeAccountId);
      const status = account.charges_enabled ? "active" : "pending";
      if (status !== store.stripeAccountStatus) {
        await db.update(storesTable).set({ stripeAccountStatus: status }).where(eq(storesTable.id, storeId));
      }
      res.json({ status, accountId: store.stripeAccountId, chargesEnabled: account.charges_enabled });
      return;
    } catch {
      /* fall through */
    }
  }

  res.json({ status: store.stripeAccountStatus ?? "not_connected", accountId: null, chargesEnabled: false });
});

// ─── Create checkout session (separate charges + transfers) ───────────────────

router.post("/stripe/checkout/:storeId", async (req: Request, res: Response): Promise<void> => {
  const storeId = parseInt(req.params.storeId, 10);
  const { items, customerEmail, successUrl, cancelUrl } = req.body as {
    items: { productId: number; quantity: number }[];
    customerEmail?: string;
    successUrl?: string;
    cancelUrl?: string;
  };

  if (!items?.length) { res.status(400).json({ error: "No items provided" }); return; }

  const [store] = await db.select().from(storesTable).where(eq(storesTable.id, storeId));
  if (!store) { res.status(404).json({ error: "Store not found" }); return; }
  if (!store.stripeAccountId || store.stripeAccountStatus !== "active") {
    res.status(422).json({ error: "This store has not completed Stripe Connect setup." });
    return;
  }

  const productIds = items.map(i => i.productId);
  const products = await db.select().from(productsTable)
    .where(and(eq(productsTable.storeId, storeId), inArray(productsTable.id, productIds)));

  if (!products.length) { res.status(400).json({ error: "No valid products found" }); return; }

  try {
    const stripe = getStripe();
    const lineItems: Stripe.Checkout.SessionCreateParams.LineItem[] = items.map(item => {
      const product = products.find(p => p.id === item.productId);
      if (!product) throw new Error(`Product ${item.productId} not found`);
      return {
        price_data: {
          currency: store.currency.toLowerCase(),
          product_data: { name: product.name, description: product.description ?? undefined, images: product.imageUrl ? [product.imageUrl] : [] },
          unit_amount: Math.round(product.price * 100),
        },
        quantity: item.quantity,
      };
    });

    const total = items.reduce((sum, item) => {
      const product = products.find(p => p.id === item.productId);
      return sum + (product ? product.price * item.quantity * 100 : 0);
    }, 0);

    const appFee = Math.round(total * PLATFORM_FEE_PERCENT);
    const baseUrl = getAppUrl();

    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items: lineItems,
      customer_email: customerEmail,
      payment_intent_data: {
        application_fee_amount: appFee,
        transfer_data: { destination: store.stripeAccountId },
      },
      success_url: successUrl ?? `${baseUrl}/store/${store.slug}/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: cancelUrl ?? `${baseUrl}/store/${store.slug}`,
      metadata: { storeId: String(storeId) },
    });

    res.json({ sessionId: session.id, url: session.url });
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Stripe error";
    res.status(500).json({ error: msg });
  }
});

// ─── Stripe Webhook ───────────────────────────────────────────────────────────

router.post("/stripe/webhook", async (req: Request, res: Response): Promise<void> => {
  const sig = req.headers["stripe-signature"] as string;
  const webhookSecret = process.env["STRIPE_WEBHOOK_SECRET"];

  let event: Stripe.Event;
  try {
    const stripe = getStripe();
    if (webhookSecret) {
      event = stripe.webhooks.constructEvent(req.body as Buffer, sig, webhookSecret);
    } else {
      event = req.body as Stripe.Event;
    }
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Webhook error";
    res.status(400).json({ error: msg });
    return;
  }

  if (event.type === "checkout.session.completed") {
    const session = event.data.object as Stripe.Checkout.Session;
    const storeId = parseInt(session.metadata?.storeId ?? "0", 10);
    if (storeId) {
      const total = (session.amount_total ?? 0) / 100;
      const platformFee = total * PLATFORM_FEE_PERCENT;
      const ownerAmount = total - platformFee;

      await db.insert(ordersTable).values({
        storeId,
        customerName: session.customer_details?.name ?? "Customer",
        customerEmail: session.customer_details?.email ?? "",
        shippingAddress: session.customer_details?.address
          ? [
            session.customer_details.address.line1,
            session.customer_details.address.city,
            session.customer_details.address.country,
          ].filter(Boolean).join(", ")
          : "Provided at checkout",
        total,
        platformFee,
        ownerAmount,
        paymentMethod: "stripe",
        status: "paid",
      });
    }
  }

  if (event.type === "account.updated") {
    const account = event.data.object as Stripe.Account;
    if (account.id) {
      const status = account.charges_enabled ? "active" : "pending";
      await db.update(storesTable)
        .set({ stripeAccountStatus: status })
        .where(eq(storesTable.stripeAccountId, account.id));
    }
  }

  res.json({ received: true });
});

export default router;
