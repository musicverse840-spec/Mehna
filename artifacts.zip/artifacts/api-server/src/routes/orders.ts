import { Router } from "express";
import { db } from "@workspace/db";
import { ordersTable, orderItemsTable, storesTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { requireAuth } from "../lib/auth";
import { ListOrdersParams, GetOrderParams, NotifySupplierParams } from "@workspace/api-zod";

const router = Router();
function intParam(p: unknown): number { return parseInt(String(Array.isArray(p) ? p[0] : p), 10); }

router.get("/stores/:storeId/orders", requireAuth, async (req, res): Promise<void> => {
  const user = (req as typeof req & { user: { id: number } }).user;
  const params = ListOrdersParams.safeParse({ storeId: intParam(req.params.storeId) });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }

  const [store] = await db.select().from(storesTable).where(and(eq(storesTable.id, params.data.storeId), eq(storesTable.userId, user.id)));
  if (!store) { res.status(404).json({ error: "Store not found" }); return; }

  const orders = await db.select().from(ordersTable).where(eq(ordersTable.storeId, params.data.storeId));
  res.json(orders);
});

router.get("/stores/:storeId/orders/:orderId", requireAuth, async (req, res): Promise<void> => {
  const user = (req as typeof req & { user: { id: number } }).user;
  const params = GetOrderParams.safeParse({
    storeId: intParam(req.params.storeId),
    orderId: intParam(req.params.orderId),
  });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }

  const [store] = await db.select().from(storesTable).where(and(eq(storesTable.id, params.data.storeId), eq(storesTable.userId, user.id)));
  if (!store) { res.status(404).json({ error: "Store not found" }); return; }

  const [order] = await db.select().from(ordersTable)
    .where(and(eq(ordersTable.id, params.data.orderId), eq(ordersTable.storeId, params.data.storeId)));
  if (!order) { res.status(404).json({ error: "Order not found" }); return; }

  const items = await db.select().from(orderItemsTable).where(eq(orderItemsTable.orderId, order.id));
  res.json({ ...order, items });
});

router.post("/stores/:storeId/orders/:orderId/notify-supplier", requireAuth, async (req, res): Promise<void> => {
  const user = (req as typeof req & { user: { id: number } }).user;
  const params = NotifySupplierParams.safeParse({
    storeId: intParam(req.params.storeId),
    orderId: intParam(req.params.orderId),
  });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }

  const [store] = await db.select().from(storesTable).where(and(eq(storesTable.id, params.data.storeId), eq(storesTable.userId, user.id)));
  if (!store) { res.status(404).json({ error: "Store not found" }); return; }

  const [order] = await db.select().from(ordersTable)
    .where(and(eq(ordersTable.id, params.data.orderId), eq(ordersTable.storeId, params.data.storeId)));
  if (!order) { res.status(404).json({ error: "Order not found" }); return; }

  await db.update(ordersTable).set({ supplierNotified: true }).where(eq(ordersTable.id, order.id));

  req.log.info({ orderId: order.id, storeId: store.id }, "Supplier notified for order");

  res.json({ message: `Supplier notified for order #${order.id}. Shipping to: ${order.shippingAddress}` });
});

export default router;
