import { Router } from "express";
import { db } from "@workspace/db";
import { usersTable, subscriptionsTable, plansTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { hashPassword, verifyPassword, generateToken, requireAuth } from "../lib/auth";
import { RegisterBody, LoginBody } from "@workspace/api-zod";
import crypto from "node:crypto";

const router = Router();

function getAppUrl(): string {
  const domains = process.env["REPLIT_DOMAINS"];
  if (domains) return `https://${domains.split(",")[0].trim()}`;
  return process.env["APP_URL"] ?? "http://localhost";
}

async function findOrCreateOAuthUser(email: string, name: string): Promise<typeof usersTable.$inferSelect> {
  const [existing] = await db.select().from(usersTable).where(eq(usersTable.email, email));
  if (existing) return existing;

  const randomHash = await hashPassword(crypto.randomBytes(32).toString("hex"));
  const [user] = await db.insert(usersTable).values({
    email,
    name: name || email.split("@")[0],
    passwordHash: randomHash,
    role: "user",
  }).returning();

  const [freePlan] = await db.select().from(plansTable).where(eq(plansTable.name, "Free"));
  if (freePlan) {
    await db.insert(subscriptionsTable).values({
      userId: user.id,
      planId: freePlan.id,
      status: "free",
    }).onConflictDoNothing();
  }

  return user;
}

router.post("/auth/register", async (req, res): Promise<void> => {
  const parsed = RegisterBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const { email, password, name } = parsed.data;
  const [existing] = await db.select().from(usersTable).where(eq(usersTable.email, email));
  if (existing) { res.status(409).json({ error: "Email already in use" }); return; }

  const passwordHash = await hashPassword(password);
  const [user] = await db.insert(usersTable).values({ email, passwordHash, name }).returning();

  const [freePlan] = await db.select().from(plansTable).where(eq(plansTable.name, "Free"));
  if (freePlan) {
    await db.insert(subscriptionsTable).values({ userId: user.id, planId: freePlan.id, status: "free" }).onConflictDoNothing();
  }

  const token = generateToken(user.id);
  res.status(201).json({
    user: { id: user.id, email: user.email, name: user.name, role: user.role, avatarUrl: user.avatarUrl ?? null, planId: freePlan?.id ?? null, createdAt: user.createdAt },
    token,
  });
});

router.post("/auth/login", async (req, res): Promise<void> => {
  const parsed = LoginBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const { email, password } = parsed.data;
  const [user] = await db.select().from(usersTable).where(eq(usersTable.email, email));
  if (!user || !(await verifyPassword(password, user.passwordHash))) { res.status(401).json({ error: "Invalid email or password" }); return; }
  if (user.isBlocked) { res.status(403).json({ error: "Account is blocked" }); return; }

  const [sub] = await db.select().from(subscriptionsTable).where(eq(subscriptionsTable.userId, user.id));
  const token = generateToken(user.id);
  res.json({ user: { id: user.id, email: user.email, name: user.name, role: user.role, avatarUrl: user.avatarUrl ?? null, planId: sub?.planId ?? null, createdAt: user.createdAt }, token });
});

router.post("/auth/logout", async (_req, res): Promise<void> => { res.sendStatus(204); });

router.get("/auth/me", requireAuth, async (req, res): Promise<void> => {
  const user = (req as typeof req & { user: typeof usersTable.$inferSelect }).user;
  const [sub] = await db.select().from(subscriptionsTable).where(eq(subscriptionsTable.userId, user.id));
  res.json({ id: user.id, email: user.email, name: user.name, role: user.role, avatarUrl: user.avatarUrl ?? null, planId: sub?.planId ?? null, createdAt: user.createdAt });
});

// ─── GitHub OAuth ─────────────────────────────────────────────────────────────
router.get("/auth/github", (_req, res): void => {
  const clientId = process.env["GITHUB_CLIENT_ID"];
  if (!clientId) { res.redirect("/login?error=oauth_not_configured"); return; }
  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: `${getAppUrl()}/api/auth/github/callback`,
    scope: "user:email",
  });
  res.redirect(`https://github.com/login/oauth/authorize?${params}`);
});

router.get("/auth/github/callback", async (req, res): Promise<void> => {
  const code = req.query["code"] as string | undefined;
  if (!code) { res.redirect("/login?error=oauth_failed"); return; }
  try {
    const tokenRes = await fetch("https://github.com/login/oauth/access_token", {
      method: "POST",
      headers: { Accept: "application/json", "Content-Type": "application/json" },
      body: JSON.stringify({ client_id: process.env["GITHUB_CLIENT_ID"], client_secret: process.env["GITHUB_CLIENT_SECRET"], code }),
    });
    const tokenData = await tokenRes.json() as { access_token?: string };
    if (!tokenData.access_token) { res.redirect("/login?error=oauth_failed"); return; }

    const [userRes, emailRes] = await Promise.all([
      fetch("https://api.github.com/user", { headers: { Authorization: `Bearer ${tokenData.access_token}`, "User-Agent": "Mehna-App" } }),
      fetch("https://api.github.com/user/emails", { headers: { Authorization: `Bearer ${tokenData.access_token}`, "User-Agent": "Mehna-App" } }),
    ]);
    const ghUser = await userRes.json() as { id: number; name?: string; login: string; email?: string };
    const emails = await emailRes.json() as { email: string; primary: boolean; verified: boolean }[];
    const email = ghUser.email ?? emails.find(e => e.primary && e.verified)?.email;
    if (!email) { res.redirect("/login?error=no_email"); return; }

    const user = await findOrCreateOAuthUser(email, ghUser.name ?? ghUser.login);
    const token = generateToken(user.id);
    res.redirect(`/login?token=${token}`);
  } catch {
    res.redirect("/login?error=oauth_failed");
  }
});

// ─── Google OAuth ─────────────────────────────────────────────────────────────
router.get("/auth/google", (_req, res): void => {
  const clientId = process.env["GOOGLE_CLIENT_ID"];
  if (!clientId) { res.redirect("/login?error=oauth_not_configured"); return; }
  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: `${getAppUrl()}/api/auth/google/callback`,
    response_type: "code",
    scope: "openid email profile",
    access_type: "offline",
  });
  res.redirect(`https://accounts.google.com/o/oauth2/v2/auth?${params}`);
});

router.get("/auth/google/callback", async (req, res): Promise<void> => {
  const code = req.query["code"] as string | undefined;
  if (!code) { res.redirect("/login?error=oauth_failed"); return; }
  try {
    const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        code,
        client_id: process.env["GOOGLE_CLIENT_ID"] ?? "",
        client_secret: process.env["GOOGLE_CLIENT_SECRET"] ?? "",
        redirect_uri: `${getAppUrl()}/api/auth/google/callback`,
        grant_type: "authorization_code",
      }),
    });
    const tokenData = await tokenRes.json() as { access_token?: string; id_token?: string };
    if (!tokenData.access_token) { res.redirect("/login?error=oauth_failed"); return; }

    const userRes = await fetch("https://www.googleapis.com/oauth2/v2/userinfo", {
      headers: { Authorization: `Bearer ${tokenData.access_token}` },
    });
    const gUser = await userRes.json() as { email?: string; name?: string };
    if (!gUser.email) { res.redirect("/login?error=no_email"); return; }

    const user = await findOrCreateOAuthUser(gUser.email, gUser.name ?? "");
    const token = generateToken(user.id);
    res.redirect(`/login?token=${token}`);
  } catch {
    res.redirect("/login?error=oauth_failed");
  }
});

// ─── Facebook OAuth ───────────────────────────────────────────────────────────
router.get("/auth/facebook", (_req, res): void => {
  const appId = process.env["FACEBOOK_APP_ID"];
  if (!appId) { res.redirect("/login?error=oauth_not_configured"); return; }
  const params = new URLSearchParams({
    client_id: appId,
    redirect_uri: `${getAppUrl()}/api/auth/facebook/callback`,
    scope: "email,public_profile",
  });
  res.redirect(`https://www.facebook.com/v19.0/dialog/oauth?${params}`);
});

router.get("/auth/facebook/callback", async (req, res): Promise<void> => {
  const code = req.query["code"] as string | undefined;
  if (!code) { res.redirect("/login?error=oauth_failed"); return; }
  try {
    const tokenRes = await fetch(
      `https://graph.facebook.com/v19.0/oauth/access_token?client_id=${process.env["FACEBOOK_APP_ID"]}&client_secret=${process.env["FACEBOOK_APP_SECRET"]}&redirect_uri=${encodeURIComponent(`${getAppUrl()}/api/auth/facebook/callback`)}&code=${code}`
    );
    const tokenData = await tokenRes.json() as { access_token?: string };
    if (!tokenData.access_token) { res.redirect("/login?error=oauth_failed"); return; }

    const userRes = await fetch(`https://graph.facebook.com/me?fields=id,name,email&access_token=${tokenData.access_token}`);
    const fbUser = await userRes.json() as { id?: string; name?: string; email?: string };
    if (!fbUser.email) { res.redirect("/login?error=no_email"); return; }

    const user = await findOrCreateOAuthUser(fbUser.email, fbUser.name ?? "");
    const token = generateToken(user.id);
    res.redirect(`/login?token=${token}`);
  } catch {
    res.redirect("/login?error=oauth_failed");
  }
});

export default router;
