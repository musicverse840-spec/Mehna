import { Router } from "express";
import { db } from "@workspace/db";
import { storesTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

function getBaseUrl(): string {
  const domains = process.env["REPLIT_DOMAINS"];
  if (domains) return `https://${domains.split(",")[0].trim()}`;
  return process.env["APP_URL"] ?? "https://mehna.app";
}

router.get("/sitemap.xml", async (_req, res): Promise<void> => {
  const base = getBaseUrl();

  const stores = await db.select({
    id: storesTable.id,
    slug: storesTable.slug,
    updatedAt: storesTable.updatedAt,
  }).from(storesTable);

  const staticPages = [
    { url: "/", priority: "1.0", changefreq: "weekly" },
    { url: "/login", priority: "0.5", changefreq: "monthly" },
    { url: "/register", priority: "0.5", changefreq: "monthly" },
    { url: "/pricing", priority: "0.8", changefreq: "monthly" },
  ];

  const now = new Date().toISOString().split("T")[0];

  const urlEntries = [
    ...staticPages.map(p => `
  <url>
    <loc>${base}${p.url}</loc>
    <lastmod>${now}</lastmod>
    <changefreq>${p.changefreq}</changefreq>
    <priority>${p.priority}</priority>
  </url>`),
    ...stores.map(s => `
  <url>
    <loc>${base}/store/${s.slug ?? s.id}</loc>
    <lastmod>${s.updatedAt ? new Date(s.updatedAt).toISOString().split("T")[0] : now}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>`),
  ];

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urlEntries.join("")}
</urlset>`;

  res.set("Content-Type", "application/xml; charset=utf-8");
  res.set("Cache-Control", "public, max-age=3600");
  res.send(xml);
});

router.get("/robots.txt", (_req, res): void => {
  const base = getBaseUrl();
  res.set("Content-Type", "text/plain; charset=utf-8");
  res.send(`User-agent: *
Allow: /
Disallow: /dashboard
Disallow: /admin
Disallow: /api/

Sitemap: ${base}/api/sitemap.xml
`);
});

export default router;
