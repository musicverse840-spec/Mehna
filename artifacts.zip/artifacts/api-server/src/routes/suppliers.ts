import { Router } from "express";
import { db } from "@workspace/db";
import { suppliersTable, supplierProductsTable } from "@workspace/db";
import { eq, ilike, or } from "drizzle-orm";
import { GetSupplierParams, ListSupplierProductsParams } from "@workspace/api-zod";

const router = Router();
function intParam(p: unknown): number { return parseInt(String(Array.isArray(p) ? p[0] : p), 10); }

router.get("/suppliers", async (req, res): Promise<void> => {
  const search = typeof req.query.search === "string" ? req.query.search : undefined;
  const suppliers = search
    ? await db.select().from(suppliersTable).where(ilike(suppliersTable.name, `%${search}%`))
    : await db.select().from(suppliersTable).where(eq(suppliersTable.isActive, true));
  res.json(suppliers);
});

router.get("/suppliers/:supplierId", async (req, res): Promise<void> => {
  const params = GetSupplierParams.safeParse({ supplierId: intParam(req.params.supplierId) });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }

  const [supplier] = await db.select().from(suppliersTable).where(eq(suppliersTable.id, params.data.supplierId));
  if (!supplier) { res.status(404).json({ error: "Supplier not found" }); return; }
  res.json(supplier);
});

router.get("/suppliers/:supplierId/products", async (req, res): Promise<void> => {
  const params = ListSupplierProductsParams.safeParse({ supplierId: intParam(req.params.supplierId) });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }

  const products = await db.select().from(supplierProductsTable)
    .where(eq(supplierProductsTable.supplierId, params.data.supplierId));
  res.json(products);
});

export default router;
