import { Router } from "express";
import { db } from "@workspace/db";
import { conversations, messages } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth } from "../../lib/auth";
import { openai } from "@workspace/integrations-openai-ai-server";

const router = Router();
function intParam(p: unknown): number { return parseInt(String(Array.isArray(p) ? p[0] : p), 10); }

const MEHNA_SYSTEM_PROMPT = `You are Mehna AI — a powerful, expert e-commerce and dropshipping assistant built into the Mehna platform.

You help store owners:
- Build and optimize their online stores
- Find winning dropshipping products and niches
- Write compelling product descriptions and marketing copy
- Understand pricing strategies (remember: Mehna takes a 5% platform fee)
- Navigate supplier relationships and order fulfillment
- Create marketing strategies for social media and ads
- Analyze competition and market trends
- Generate business ideas and store concepts

You have deep knowledge of:
- CJ Dropshipping, AliExpress, and Chinese supplier ecosystems
- E-commerce best practices (Shopify, WooCommerce, etc.)
- Social media marketing (TikTok, Instagram, Facebook ads)
- Product research tools and methodologies
- Global payment systems including Stripe, PayPal
- SEO and conversion optimization

Be direct, actionable, and specific. Give real numbers, real strategies, real supplier names when helpful.
You are the competitive advantage that makes Mehna users more successful than those using other platforms.`;

router.get("/openai/conversations", requireAuth, async (req, res): Promise<void> => {
  const user = (req as typeof req & { user: { id: number } }).user;
  const convos = await db.select().from(conversations).where(eq(conversations.userId, user.id));
  res.json(convos);
});

router.post("/openai/conversations", requireAuth, async (req, res): Promise<void> => {
  const user = (req as typeof req & { user: { id: number } }).user;
  const { title } = req.body;
  if (!title) { res.status(400).json({ error: "Title is required" }); return; }

  const [convo] = await db.insert(conversations).values({ title, userId: user.id }).returning();
  res.status(201).json(convo);
});

router.get("/openai/conversations/:id", requireAuth, async (req, res): Promise<void> => {
  const user = (req as typeof req & { user: { id: number } }).user;
  const id = intParam(req.params.id);
  const [convo] = await db.select().from(conversations).where(eq(conversations.id, id));
  if (!convo) { res.status(404).json({ error: "Conversation not found" }); return; }

  const msgs = await db.select().from(messages).where(eq(messages.conversationId, id));
  res.json({ ...convo, messages: msgs });
});

router.delete("/openai/conversations/:id", requireAuth, async (req, res): Promise<void> => {
  const id = intParam(req.params.id);
  await db.delete(messages).where(eq(messages.conversationId, id));
  await db.delete(conversations).where(eq(conversations.id, id));
  res.sendStatus(204);
});

router.get("/openai/conversations/:id/messages", requireAuth, async (req, res): Promise<void> => {
  const id = intParam(req.params.id);
  const msgs = await db.select().from(messages).where(eq(messages.conversationId, id));
  res.json(msgs);
});

router.post("/openai/conversations/:id/messages", requireAuth, async (req, res): Promise<void> => {
  const id = intParam(req.params.id);
  const { content } = req.body;
  if (!content) { res.status(400).json({ error: "Content is required" }); return; }

  await db.insert(messages).values({ conversationId: id, role: "user", content });

  const prevMessages = await db.select().from(messages).where(eq(messages.conversationId, id));

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  let fullResponse = "";

  const stream = await openai.chat.completions.create({
    model: "gpt-5.4",
    max_completion_tokens: 8192,
    messages: [
      { role: "system", content: MEHNA_SYSTEM_PROMPT },
      ...prevMessages.slice(-20).map(m => ({
        role: m.role as "user" | "assistant",
        content: m.content,
      })),
    ],
    stream: true,
  });

  for await (const chunk of stream) {
    const content_ = chunk.choices[0]?.delta?.content;
    if (content_) {
      fullResponse += content_;
      res.write(`data: ${JSON.stringify({ content: content_ })}\n\n`);
    }
  }

  await db.insert(messages).values({ conversationId: id, role: "assistant", content: fullResponse });

  res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
  res.end();
});

router.post("/openai/conversations/:id/voice-messages", requireAuth, async (req, res): Promise<void> => {
  const id = intParam(req.params.id);
  const { audio } = req.body;
  if (!audio) { res.status(400).json({ error: "Audio data is required" }); return; }

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  const audioBuffer = Buffer.from(audio, "base64");
  const { ensureCompatibleFormat, voiceChatStream } = await import("@workspace/integrations-openai-ai-server/audio");

  const { buffer, format } = await ensureCompatibleFormat(audioBuffer);
  const stream = await voiceChatStream(buffer, "alloy", format);

  let assistantTranscript = "";
  let userTranscript = "";

  for await (const event of stream) {
    if (event.type === "transcript") assistantTranscript += event.data;
    if (event.type === "user_transcript") userTranscript += event.data;
    res.write(`data: ${JSON.stringify(event)}\n\n`);
  }

  await db.insert(messages).values([
    { conversationId: id, role: "user", content: userTranscript || "[voice message]" },
    { conversationId: id, role: "assistant", content: assistantTranscript },
  ]);

  res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
  res.end();
});

router.post("/openai/generate-image", requireAuth, async (req, res): Promise<void> => {
  const { prompt, size } = req.body;
  if (!prompt) { res.status(400).json({ error: "Prompt is required" }); return; }

  const { generateImageBuffer } = await import("@workspace/integrations-openai-ai-server/image");
  const buffer = await generateImageBuffer(prompt, (size as "1024x1024" | "1536x1024" | "1024x1536") ?? "1024x1024");
  res.json({ b64_json: buffer.toString("base64") });
});

export default router;
