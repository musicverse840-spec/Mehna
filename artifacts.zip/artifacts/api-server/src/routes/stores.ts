import { Router } from "express";
import { db } from "@workspace/db";
import { storesTable, productsTable, ordersTable, subscriptionsTable, plansTable } from "@workspace/db";
import { eq, and, count, sum } from "drizzle-orm";
import { requireAuth } from "../lib/auth";
import { CreateStoreBody, AiGenerateStoreBody, GetStoreParams, UpdateStoreParams, UpdateStoreBody, DeleteStoreParams, GetStoreStatsParams } from "@workspace/api-zod";
import { openai } from "@workspace/integrations-openai-ai-server";

const router = Router();

function toRaw(p: unknown) { return Array.isArray(p) ? p[0] : p; }
function intParam(p: unknown): number { return parseInt(String(toRaw(p)), 10); }

router.get("/stores", requireAuth, async (req, res): Promise<void> => {
  const user = (req as typeof req & { user: { id: number } }).user;
  const stores = await db.select().from(storesTable).where(eq(storesTable.userId, user.id));
  res.json(stores);
});

router.post("/stores", requireAuth, async (req, res): Promise<void> => {
  const user = (req as typeof req & { user: { id: number } }).user;
  const parsed = CreateStoreBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const canCreate = await checkStoreLimit(user.id);
  if (!canCreate) {
    res.status(403).json({ error: "Store limit reached for your plan. Please upgrade." });
    return;
  }

  const slug = `${parsed.data.name.toLowerCase().replace(/[^a-z0-9]/g, "-")}-${Date.now()}`;
  const [store] = await db.insert(storesTable).values({ ...parsed.data, userId: user.id, slug }).returning();
  res.status(201).json(store);
});

router.post("/stores/ai-generate", requireAuth, async (req, res): Promise<void> => {
  const user = (req as typeof req & { user: { id: number } }).user;
  const parsed = AiGenerateStoreBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const canCreate = await checkStoreLimit(user.id);
  if (!canCreate) {
    res.status(403).json({ error: "Store limit reached for your plan. Please upgrade." });
    return;
  }

  const prompt = parsed.data.prompt;
  const completion = await openai.chat.completions.create({
    model: "gpt-5.4",
    max_completion_tokens: 1024,
    messages: [
      {
        role: "system",
        content: `You are a store builder AI. Generate a store configuration from the user's prompt.
Return ONLY valid JSON with these exact fields:
{
  "name": "Store name",
  "description": "Short store description",
  "category": "Electronics|Fashion|Home|Beauty|Sports|Food|Other",
  "primaryColor": "#HEX color appropriate for the niche"
}`,
      },
      { role: "user", content: prompt },
    ],
  });

  let storeData: { name: string; description: string; category: string; primaryColor: string };
  try {
    const text = completion.choices[0]?.message?.content ?? "{}";
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    storeData = JSON.parse(jsonMatch?.[0] ?? "{}");
  } catch {
    storeData = { name: "My Store", description: prompt, category: "Other", primaryColor: "#FFD700" };
  }

  const slug = `${storeData.name.toLowerCase().replace(/[^a-z0-9]/g, "-")}-${Date.now()}`;
  const [store] = await db.insert(storesTable).values({
    userId: user.id,
    slug,
    name: storeData.name || "My Store",
    description: storeData.description || "",
    category: storeData.category || "Other",
    primaryColor: storeData.primaryColor || "#FFD700",
  }).returning();

  res.status(201).json(store);
});

router.get("/stores/:storeId", requireAuth, async (req, res): Promise<void> => {
  const user = (req as typeof req & { user: { id: number } }).user;
  const params = GetStoreParams.safeParse({ storeId: intParam(req.params.storeId) });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }

  const [store] = await db.select().from(storesTable)
    .where(and(eq(storesTable.id, params.data.storeId), eq(storesTable.userId, user.id)));
  if (!store) { res.status(404).json({ error: "Store not found" }); return; }
  res.json(store);
});

router.patch("/stores/:storeId", requireAuth, async (req, res): Promise<void> => {
  const user = (req as typeof req & { user: { id: number } }).user;
  const params = UpdateStoreParams.safeParse({ storeId: intParam(req.params.storeId) });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }

  const parsed = UpdateStoreBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const [store] = await db.update(storesTable)
    .set(parsed.data)
    .where(and(eq(storesTable.id, params.data.storeId), eq(storesTable.userId, user.id)))
    .returning();
  if (!store) { res.status(404).json({ error: "Store not found" }); return; }
  res.json(store);
});

router.delete("/stores/:storeId", requireAuth, async (req, res): Promise<void> => {
  const user = (req as typeof req & { user: { id: number } }).user;
  const params = DeleteStoreParams.safeParse({ storeId: intParam(req.params.storeId) });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }

  const [store] = await db.delete(storesTable)
    .where(and(eq(storesTable.id, params.data.storeId), eq(storesTable.userId, user.id)))
    .returning();
  if (!store) { res.status(404).json({ error: "Store not found" }); return; }
  res.sendStatus(204);
});

router.get("/stores/:storeId/stats", requireAuth, async (req, res): Promise<void> => {
  const user = (req as typeof req & { user: { id: number } }).user;
  const params = GetStoreStatsParams.safeParse({ storeId: intParam(req.params.storeId) });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }

  const [store] = await db.select().from(storesTable)
    .where(and(eq(storesTable.id, params.data.storeId), eq(storesTable.userId, user.id)));
  if (!store) { res.status(404).json({ error: "Store not found" }); return; }

  const [productCount] = await db.select({ c: count() }).from(productsTable).where(eq(productsTable.storeId, store.id));
  const orders = await db.select().from(ordersTable).where(eq(ordersTable.storeId, store.id));
  const totalRevenue = orders.reduce((s, o) => s + o.total, 0);
  const totalPlatformFee = orders.reduce((s, o) => s + o.platformFee, 0);

  const now = new Date();
  const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
  const recentOrders = orders.filter(o => o.createdAt >= thirtyDaysAgo).length;

  res.json({
    totalOrders: orders.length,
    totalRevenue,
    totalProducts: productCount?.c ?? 0,
    recentOrders,
    platformFee: totalPlatformFee,
    conversionRate: orders.length > 0 ? 0.034 : 0,
  });
});

async function checkStoreLimit(userId: number): Promise<boolean> {
  const [sub] = await db.select({ planId: subscriptionsTable.planId })
    .from(subscriptionsTable).where(eq(subscriptionsTable.userId, userId));
  const planId = sub?.planId ?? null;
  const [plan] = planId ? await db.select().from(plansTable).where(eq(plansTable.id, planId)) : [];
  const maxStores = plan?.maxStores ?? 1;
  const [storeCount] = await db.select({ c: count() }).from(storesTable).where(eq(storesTable.userId, userId));
  return (storeCount?.c ?? 0) < maxStores;
}

export default router;
