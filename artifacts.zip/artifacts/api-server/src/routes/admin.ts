import { Router } from "express";
import { db } from "@workspace/db";
import { usersTable, storesTable, ordersTable, subscriptionsTable, plansTable } from "@workspace/db";
import { eq, count, sum, ilike } from "drizzle-orm";
import { requireAdmin } from "../lib/auth";
import { GetAdminUserParams, UpdateAdminUserParams, UpdateAdminUserBody } from "@workspace/api-zod";

const router = Router();
function intParam(p: unknown): number { return parseInt(String(Array.isArray(p) ? p[0] : p), 10); }

router.get("/admin/stats", requireAdmin, async (_req, res): Promise<void> => {
  const [userCount] = await db.select({ c: count() }).from(usersTable);
  const [storeCount] = await db.select({ c: count() }).from(storesTable);
  const allOrders = await db.select().from(ordersTable);
  const totalRevenue = allOrders.reduce((s, o) => s + o.total, 0);
  const platformFeeCollected = allOrders.reduce((s, o) => s + o.platformFee, 0);

  const [activeSubs] = await db.select({ c: count() }).from(subscriptionsTable)
    .where(eq(subscriptionsTable.status, "active"));

  const now = new Date();
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
  const newUsersThisMonth = (await db.select().from(usersTable))
    .filter(u => u.createdAt >= startOfMonth).length;
  const ordersThisMonth = allOrders.filter(o => o.createdAt >= startOfMonth).length;

  res.json({
    totalUsers: userCount?.c ?? 0,
    totalStores: storeCount?.c ?? 0,
    totalOrders: allOrders.length,
    totalRevenue,
    platformFeeCollected,
    activeSubscriptions: activeSubs?.c ?? 0,
    newUsersThisMonth,
    ordersThisMonth,
  });
});

router.get("/admin/users", requireAdmin, async (req, res): Promise<void> => {
  const search = typeof req.query.search === "string" ? req.query.search : undefined;
  const users = search
    ? await db.select().from(usersTable).where(ilike(usersTable.email, `%${search}%`))
    : await db.select().from(usersTable);

  const result = await Promise.all(users.map(async u => {
    const [sub] = await db.select({ planId: subscriptionsTable.planId })
      .from(subscriptionsTable).where(eq(subscriptionsTable.userId, u.id));
    const [plan] = sub ? await db.select({ name: plansTable.name }).from(plansTable).where(eq(plansTable.id, sub.planId)) : [];
    const [storeCnt] = await db.select({ c: count() }).from(storesTable).where(eq(storesTable.userId, u.id));
    const orders = await db.select().from(ordersTable);
    const userStores = await db.select({ id: storesTable.id }).from(storesTable).where(eq(storesTable.userId, u.id));
    const storeIds = new Set(userStores.map(s => s.id));
    const userOrders = orders.filter(o => storeIds.has(o.storeId));
    const totalRevenue = userOrders.reduce((s, o) => s + o.ownerAmount, 0);

    return {
      id: u.id,
      email: u.email,
      name: u.name,
      role: u.role,
      planName: plan?.name ?? null,
      storeCount: storeCnt?.c ?? 0,
      orderCount: userOrders.length,
      totalRevenue,
      isBlocked: u.isBlocked,
      createdAt: u.createdAt,
    };
  }));

  res.json(result);
});

router.get("/admin/users/:userId", requireAdmin, async (req, res): Promise<void> => {
  const params = GetAdminUserParams.safeParse({ userId: intParam(req.params.userId) });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }

  const [u] = await db.select().from(usersTable).where(eq(usersTable.id, params.data.userId));
  if (!u) { res.status(404).json({ error: "User not found" }); return; }

  const [sub] = await db.select({ planId: subscriptionsTable.planId })
    .from(subscriptionsTable).where(eq(subscriptionsTable.userId, u.id));
  const [plan] = sub ? await db.select({ name: plansTable.name }).from(plansTable).where(eq(plansTable.id, sub.planId)) : [];
  const [storeCnt] = await db.select({ c: count() }).from(storesTable).where(eq(storesTable.userId, u.id));

  res.json({
    id: u.id,
    email: u.email,
    name: u.name,
    role: u.role,
    planName: plan?.name ?? null,
    storeCount: storeCnt?.c ?? 0,
    orderCount: 0,
    totalRevenue: 0,
    isBlocked: u.isBlocked,
    createdAt: u.createdAt,
  });
});

router.patch("/admin/users/:userId", requireAdmin, async (req, res): Promise<void> => {
  const params = UpdateAdminUserParams.safeParse({ userId: intParam(req.params.userId) });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }

  const parsed = UpdateAdminUserBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const [u] = await db.update(usersTable).set(parsed.data).where(eq(usersTable.id, params.data.userId)).returning();
  if (!u) { res.status(404).json({ error: "User not found" }); return; }

  res.json({ id: u.id, email: u.email, name: u.name, role: u.role, planName: null, storeCount: 0, orderCount: 0, totalRevenue: 0, isBlocked: u.isBlocked, createdAt: u.createdAt });
});

router.get("/admin/orders", requireAdmin, async (req, res): Promise<void> => {
  const orders = await db.select().from(ordersTable);
  res.json(orders);
});

export default router;
