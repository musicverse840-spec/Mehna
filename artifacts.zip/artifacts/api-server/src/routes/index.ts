import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import usersRouter from "./users";
import storesRouter from "./stores";
import productsRouter from "./products";
import suppliersRouter from "./suppliers";
import ordersRouter from "./orders";
import cartRouter from "./cart";
import subscriptionsRouter from "./subscriptions";
import adminRouter from "./admin";
import openaiRouter from "./openai";
import sitemapRouter from "./sitemap";
import stripeRouter from "./stripe";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(usersRouter);
router.use(storesRouter);
router.use(productsRouter);
router.use(suppliersRouter);
router.use(ordersRouter);
router.use(cartRouter);
router.use(subscriptionsRouter);
router.use(adminRouter);
router.use(openaiRouter);
router.use(sitemapRouter);
router.use(stripeRouter);

export default router;
