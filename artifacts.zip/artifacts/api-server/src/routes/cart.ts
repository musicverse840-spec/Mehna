import { Router } from "express";
import { db } from "@workspace/db";
import { storesTable, productsTable, ordersTable, orderItemsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { GetCartParams, AddToCartParams, AddToCartBody, RemoveFromCartParams, CheckoutParams, CheckoutBody } from "@workspace/api-zod";

const router = Router();
function intParam(p: unknown): number { return parseInt(String(Array.isArray(p) ? p[0] : p), 10); }

const cartStore = new Map<string, Array<{ productId: number; quantity: number }>>();

function getCartKey(storeId: number, sessionId: string): string {
  return `${storeId}:${sessionId}`;
}

function getSessionId(req: { headers: { [key: string]: string | string[] | undefined } }): string {
  const auth = req.headers.authorization;
  return typeof auth === "string" ? auth.replace("Bearer ", "").slice(0, 20) : "anon";
}

router.get("/stores/:storeId/cart", async (req, res): Promise<void> => {
  const params = GetCartParams.safeParse({ storeId: intParam(req.params.storeId) });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }

  const sessionId = getSessionId(req);
  const key = getCartKey(params.data.storeId, sessionId);
  const items = cartStore.get(key) ?? [];

  const cartItems = await Promise.all(
    items.map(async ({ productId, quantity }) => {
      const [product] = await db.select().from(productsTable).where(eq(productsTable.id, productId));
      if (!product) return null;
      return { productId, productName: product.name, price: product.price, quantity, imageUrl: product.imageUrl ?? null };
    })
  );

  const validItems = cartItems.filter(Boolean) as Array<{ productId: number; productName: string; price: number; quantity: number; imageUrl: string | null }>;
  const subtotal = validItems.reduce((s, i) => s + i.price * i.quantity, 0);
  const platformFee = subtotal * 0.05;

  res.json({ items: validItems, subtotal, platformFee, total: subtotal + platformFee });
});

router.post("/stores/:storeId/cart/items", async (req, res): Promise<void> => {
  const params = AddToCartParams.safeParse({ storeId: intParam(req.params.storeId) });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }

  const parsed = AddToCartBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const sessionId = getSessionId(req);
  const key = getCartKey(params.data.storeId, sessionId);
  const items = cartStore.get(key) ?? [];
  const existing = items.find(i => i.productId === parsed.data.productId);

  if (existing) {
    existing.quantity += parsed.data.quantity;
  } else {
    items.push({ productId: parsed.data.productId, quantity: parsed.data.quantity });
  }
  cartStore.set(key, items);

  const cartItems = await Promise.all(
    items.map(async ({ productId, quantity }) => {
      const [product] = await db.select().from(productsTable).where(eq(productsTable.id, productId));
      if (!product) return null;
      return { productId, productName: product.name, price: product.price, quantity, imageUrl: product.imageUrl ?? null };
    })
  );

  const validItems = cartItems.filter(Boolean) as Array<{ productId: number; productName: string; price: number; quantity: number; imageUrl: string | null }>;
  const subtotal = validItems.reduce((s, i) => s + i.price * i.quantity, 0);
  const platformFee = subtotal * 0.05;

  res.json({ items: validItems, subtotal, platformFee, total: subtotal + platformFee });
});

router.delete("/stores/:storeId/cart/items/:productId", async (req, res): Promise<void> => {
  const params = RemoveFromCartParams.safeParse({
    storeId: intParam(req.params.storeId),
    productId: intParam(req.params.productId),
  });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }

  const sessionId = getSessionId(req);
  const key = getCartKey(params.data.storeId, sessionId);
  const items = (cartStore.get(key) ?? []).filter(i => i.productId !== params.data.productId);
  cartStore.set(key, items);

  const cartItems = await Promise.all(
    items.map(async ({ productId, quantity }) => {
      const [product] = await db.select().from(productsTable).where(eq(productsTable.id, productId));
      if (!product) return null;
      return { productId, productName: product.name, price: product.price, quantity, imageUrl: product.imageUrl ?? null };
    })
  );

  const validItems = cartItems.filter(Boolean) as Array<{ productId: number; productName: string; price: number; quantity: number; imageUrl: string | null }>;
  const subtotal = validItems.reduce((s, i) => s + i.price * i.quantity, 0);
  const platformFee = subtotal * 0.05;
  res.json({ items: validItems, subtotal, platformFee, total: subtotal + platformFee });
});

router.post("/stores/:storeId/checkout", async (req, res): Promise<void> => {
  const params = CheckoutParams.safeParse({ storeId: intParam(req.params.storeId) });
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }

  const parsed = CheckoutBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const [store] = await db.select().from(storesTable).where(eq(storesTable.id, params.data.storeId));
  if (!store) { res.status(404).json({ error: "Store not found" }); return; }

  const sessionId = getSessionId(req);
  const key = getCartKey(params.data.storeId, sessionId);
  const items = cartStore.get(key) ?? [];

  const cartItems = await Promise.all(
    items.map(async ({ productId, quantity }) => {
      const [product] = await db.select().from(productsTable).where(eq(productsTable.id, productId));
      if (!product) return null;
      return { productId, productName: product.name, price: product.price, quantity };
    })
  );

  const validItems = cartItems.filter(Boolean) as Array<{ productId: number; productName: string; price: number; quantity: number }>;
  const subtotal = validItems.reduce((s, i) => s + i.price * i.quantity, 0);
  const platformFee = Math.round(subtotal * 0.05 * 100) / 100;
  const ownerAmount = Math.round((subtotal - platformFee) * 100) / 100;

  const [order] = await db.insert(ordersTable).values({
    storeId: params.data.storeId,
    customerName: parsed.data.customerName,
    customerEmail: parsed.data.customerEmail,
    customerPhone: parsed.data.customerPhone ?? null,
    shippingAddress: parsed.data.shippingAddress,
    status: "pending",
    total: subtotal,
    platformFee,
    ownerAmount,
    paymentMethod: parsed.data.paymentMethod,
    notes: parsed.data.notes ?? null,
    supplierNotified: false,
  }).returning();

  await Promise.all(
    validItems.map(item =>
      db.insert(orderItemsTable).values({
        orderId: order.id,
        productId: item.productId,
        productName: item.productName,
        quantity: item.quantity,
        price: item.price,
      })
    )
  );

  cartStore.delete(key);
  res.status(201).json(order);
});

export default router;
